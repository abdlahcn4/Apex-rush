import { index, integer, pgTable, serial, timestamp, varchar } from "drizzle-orm/pg-core";

/** Leaderboard entries submitted by players on this LAN server. */
export const scores = pgTable(
  "scores",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 24 }).notNull(),
    mode: varchar("mode", { length: 24 }).notNull(),
    value: integer("value").notNull(),
    car: varchar("car", { length: 24 }).notNull().default("vortex"),
    createdAt: timestamp("created_at").defaultNow().notNull(),
  },
  (t) => [index("scores_mode_value_idx").on(t.mode, t.value)],
);
