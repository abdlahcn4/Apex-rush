import { db } from "@/db";
import { scores } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

// lower is better for time-based modes, higher is better for score modes
const MODES: Record<string, "asc" | "desc"> = {
  timetrial: "asc",
  bestlap: "asc",
  traffic: "desc",
  checkpoint: "desc",
  airace: "asc",
};

export async function GET(req: Request) {
  const mode = new URL(req.url).searchParams.get("mode") ?? "timetrial";
  if (!MODES[mode]) return Response.json({ error: "bad mode" }, { status: 400 });
  try {
    const rows = await db
      .select({ name: scores.name, value: scores.value, car: scores.car, createdAt: scores.createdAt })
      .from(scores)
      .where(eq(scores.mode, mode))
      .orderBy(MODES[mode] === "asc" ? asc(scores.value) : desc(scores.value))
      .limit(10);
    return Response.json({ mode, order: MODES[mode], rows });
  } catch {
    return Response.json({ mode, order: MODES[mode], rows: [], offline: true });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const mode = String(body.mode ?? "");
    const value = Math.round(Number(body.value));
    const name = String(body.name ?? "Racer").replace(/[<>&"']/g, "").trim().slice(0, 16) || "Racer";
    const car = String(body.car ?? "vortex").slice(0, 24);
    if (!MODES[mode] || !Number.isFinite(value) || value <= 0 || value > 100_000_000) {
      return Response.json({ error: "invalid" }, { status: 400 });
    }
    await db.insert(scores).values({ name, mode, value, car });
    return Response.json({ ok: true });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
