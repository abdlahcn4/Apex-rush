import { getLanAddresses } from "@/server/lan";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const host = req.headers.get("host") ?? "";
  const m = host.match(/:(\d+)$/);
  const g = globalThis as unknown as { __raceRealtime?: { mode: string; port: number } };
  const rt = g.__raceRealtime ?? null;
  const port = m ? Number(m[1]) : rt?.mode === "attached" ? rt.port : Number(process.env.PORT || 3000);
  const addresses = getLanAddresses();
  return Response.json({
    addresses,
    port,
    urls: addresses.map((a) => `http://${a.address}:${port}`),
    realtime: rt,
    maxPlayersCap: Math.max(2, Math.min(16, parseInt(process.env.MAX_PLAYERS || "8", 10) || 8)),
  });
}
