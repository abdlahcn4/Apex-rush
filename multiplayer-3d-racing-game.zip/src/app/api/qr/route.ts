import QRCode from "qrcode";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const text = new URL(req.url).searchParams.get("text") ?? "";
  if (!/^https?:\/\//.test(text) || text.length > 300) {
    return new Response("bad text", { status: 400 });
  }
  const svg = await QRCode.toString(text, {
    type: "svg",
    margin: 1,
    color: { dark: "#0b0f1a", light: "#ffffff" },
  });
  return new Response(svg, { headers: { "content-type": "image/svg+xml", "cache-control": "no-store" } });
}
