import { redirect } from "next/navigation";

// The game is a static Three.js app served from /public/index.html.
// next.config.ts rewrites "/" to it; this redirect is a safety net.
export default function HomePage() {
  redirect("/index.html");
}
