/* eslint-disable @typescript-eslint/no-explicit-any */
import http from "http";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { Server, type Socket } from "socket.io";
import { getLanAddresses } from "./lan";

/* ------------------------------------------------------------------ */
/* Track data: shared JSON with the browser client (public/js)        */
/* ------------------------------------------------------------------ */
type TrackData = { points: [number, number][]; checkpointRadius: number };
const FALLBACK_TRACK: TrackData = {
  checkpointRadius: 26,
  points: [
    [0, 0], [0, 280], [42, 490], [182, 616], [392, 630], [560, 546], [630, 392], [602, 210],
    [490, 84], [448, -84], [532, -266], [490, -434], [322, -504], [140, -462], [28, -308],
  ],
};
function loadTrack(): TrackData {
  try {
    const file = path.join(process.cwd(), "public", "js", "trackdata.json");
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (Array.isArray(data.points) && data.points.length > 3) return data;
  } catch {
    /* use fallback */
  }
  return FALLBACK_TRACK;
}
const TRACK = loadTrack();
const CPS = TRACK.points;
const NCP = CPS.length;
const CP_R2 = TRACK.checkpointRadius * TRACK.checkpointRadius;

/* ------------------------------------------------------------------ */
const MAX_CAP = Math.max(2, Math.min(16, parseInt(process.env.MAX_PLAYERS || "8", 10) || 8));
const TICK_MS = 50; // 20 Hz snapshots
const LOBBY_GRACE = 20_000;
const RACE_GRACE = 60_000;
const FINISH_TIMEOUT = 30_000;
const COUNTDOWN_MS = 4_000;
const CARS = ["vortex", "falcon", "titan", "nimbus", "raptor", "phantom"];
const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

type RoomState = "lobby" | "countdown" | "racing" | "results";
interface Player {
  pid: string;
  key: string;
  socketId: string | null;
  name: string;
  car: string;
  color: string;
  ready: boolean;
  connected: boolean;
  disconnectedAt: number;
  joinedAt: number;
  device: string;
  s: number[]; // x, z, h, speed, steer, throttle, brake, drift
  lastStateAt: number;
  lap: number;
  nextCp: number;
  finished: boolean;
  finishTime: number | null;
  grid: number;
  ping: number;
}
interface Room {
  code: string;
  hostPid: string;
  maxPlayers: number;
  laps: number;
  state: RoomState;
  players: Map<string, Player>;
  countdownEnd: number;
  startTime: number;
  firstFinishAt: number | null;
  raceId: number;
  results: any[] | null;
  emptySince: number | null;
}

const rooms = new Map<string, Room>();
const keyIndex = new Map<string, { code: string; pid: string }>();

const clean = (v: unknown, def: string) => {
  const s = typeof v === "string" ? v.replace(/[<>&"']/g, "").trim().slice(0, 16) : "";
  return s || def;
};
const cleanCar = (v: unknown) => (typeof v === "string" && CARS.includes(v) ? v : "vortex");
const cleanColor = (v: unknown) => (typeof v === "string" && /^#[0-9a-f]{6}$/i.test(v) ? v : "#2ecc40");
const clampInt = (v: unknown, lo: number, hi: number, def: number) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : def;
};

function newCode(): string {
  for (let i = 0; i < 1000; i++) {
    let c = "";
    for (let j = 0; j < 4; j++) c += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];
    if (!rooms.has(c)) return c;
  }
  return crypto.randomBytes(3).toString("hex").toUpperCase();
}

function roomInfo(room: Room) {
  return {
    code: room.code,
    hostPid: room.hostPid,
    maxPlayers: room.maxPlayers,
    laps: room.laps,
    state: room.state,
    players: [...room.players.values()].map((p) => ({
      pid: p.pid,
      name: p.name,
      car: p.car,
      color: p.color,
      ready: p.ready,
      connected: p.connected,
      grid: p.grid,
      ping: p.ping,
      device: p.device,
    })),
  };
}

function progressOf(p: Player) {
  const passed = p.nextCp === 0 ? NCP - 1 : p.nextCp - 1;
  const total = (p.lap - 1) * NCP + passed;
  const cp = CPS[p.nextCp];
  const d = p.s.length ? Math.hypot(p.s[0] - cp[0], p.s[1] - cp[1]) : 1e6;
  return { total, d };
}

function standings(room: Room) {
  const list = [...room.players.values()].filter((p) => p.grid >= 0);
  list.sort((a, b) => {
    if (a.finished !== b.finished) return a.finished ? -1 : 1;
    if (a.finished && b.finished) return (a.finishTime ?? 0) - (b.finishTime ?? 0);
    const pa = progressOf(a);
    const pb = progressOf(b);
    if (pa.total !== pb.total) return pb.total - pa.total;
    return pa.d - pb.d;
  });
  return list.map((p, i) => ({
    pid: p.pid,
    name: p.name,
    car: p.car,
    color: p.color,
    pos: i + 1,
    lap: Math.min(p.lap, room.laps),
    nextCp: p.nextCp,
    finished: p.finished,
    time: p.finishTime,
    connected: p.connected,
  }));
}

function raceSnapshot(room: Room, p: Player) {
  const now = Date.now();
  return {
    state: room.state,
    laps: room.laps,
    countdownMs: room.state === "countdown" ? Math.max(0, room.countdownEnd - now) : 0,
    elapsed: room.state === "racing" ? now - room.startTime : 0,
    lap: p.lap,
    nextCp: p.nextCp,
    finished: p.finished,
    grid: p.grid,
    s: p.s,
    gridMap: Object.fromEntries([...room.players.values()].map((q) => [q.pid, q.grid])),
  };
}

export function startRealtime() {
  const g = globalThis as any;
  if (g.__raceRealtimeStarted) return;
  g.__raceRealtimeStarted = true;

  let tries = 0;
  const attempt = () => {
    const srv = findServer();
    if (srv) {
      attachTo(srv);
      return;
    }
    if (++tries < 60) {
      const t = setTimeout(attempt, 250);
      t.unref?.();
    } else {
      startStandalone();
    }
  };
  attempt();
}

function findServer(): http.Server | null {
  const g = globalThis as any;
  if (g.__RACE_HTTP_SERVER && g.__RACE_HTTP_SERVER.listening) return g.__RACE_HTTP_SERVER;
  const handles: unknown[] = typeof (process as any)._getActiveHandles === "function" ? (process as any)._getActiveHandles() : [];
  for (const h of handles) {
    if (h instanceof http.Server && h.listening) return h;
  }
  return null;
}

function attachTo(server: http.Server) {
  // Keep Next.js away from Socket.IO websocket upgrades
  const prev = server.listeners("upgrade").slice() as ((...a: any[]) => void)[];
  server.removeAllListeners("upgrade");
  server.on("upgrade", (req: http.IncomingMessage, socket: any, head: Buffer) => {
    if (req.url && req.url.startsWith("/socket.io")) return;
    for (const l of prev) l.call(server, req, socket, head);
  });
  const io = new Server(server, {
    path: "/socket.io",
    cors: { origin: true, credentials: true },
    destroyUpgrade: false,
    pingInterval: 5000,
    pingTimeout: 10000,
  });
  const addr = server.address();
  const port = typeof addr === "object" && addr ? addr.port : Number(process.env.PORT || 3000);
  (globalThis as any).__raceRealtime = { mode: "attached", port };
  setupIo(io);
  announce(port);
}

function startStandalone() {
  const port = Number(process.env.SOCKET_PORT || Number(process.env.PORT || 3000) + 1);
  const server = http.createServer((_req, res) => {
    res.writeHead(200, { "content-type": "text/plain" });
    res.end("Apex Rush realtime server");
  });
  const io = new Server(server, { cors: { origin: true, credentials: true }, pingInterval: 5000, pingTimeout: 10000 });
  server.listen(port, "0.0.0.0");
  (globalThis as any).__raceRealtime = { mode: "standalone", port };
  setupIo(io);
  announce(port, true);
}

function announce(port: number, standalone = false) {
  const ips = getLanAddresses();
  console.log("\n🏁 APEX RUSH multiplayer server ready" + (standalone ? ` (socket port ${port})` : ""));
  const webPort = standalone ? Number(process.env.PORT || 3000) : port;
  console.log(`   Local:   http://localhost:${webPort}`);
  for (const a of ips) console.log(`   LAN:     http://${a.address}:${webPort}   (${a.iface})`);
  console.log("   Open the LAN address on phones connected to the same Wi-Fi.\n");
}

/* ------------------------------------------------------------------ */
function setupIo(io: Server) {
  const sendRoom = (room: Room) => io.to(room.code).emit("room:update", roomInfo(room));

  const removePlayer = (room: Room, pid: string) => {
    const p = room.players.get(pid);
    if (!p) return;
    room.players.delete(pid);
    keyIndex.delete(p.key);
    if (p.socketId) io.sockets.sockets.get(p.socketId)?.leave(room.code);
    if (room.hostPid === pid) reassignHost(room);
    if (room.players.size === 0) {
      rooms.delete(room.code);
      return;
    }
    checkAllFinished(room);
    sendRoom(room);
  };

  const reassignHost = (room: Room) => {
    const next = [...room.players.values()].filter((p) => p.connected).sort((a, b) => a.joinedAt - b.joinedAt)[0];
    const any = next ?? [...room.players.values()][0];
    if (any) {
      room.hostPid = any.pid;
      any.ready = true;
    }
  };

  const endRace = (room: Room, raceId: number) => {
    if (room.raceId !== raceId || room.state !== "racing") return;
    room.state = "results";
    const st = standings(room);
    room.results = st.map((r) => ({ ...r, dnf: !r.finished }));
    for (const p of room.players.values()) p.ready = p.pid === room.hostPid;
    io.to(room.code).emit("race:results", { results: room.results, laps: room.laps });
    sendRoom(room);
  };

  const checkAllFinished = (room: Room) => {
    if (room.state !== "racing") return;
    // disconnected players inside their reconnect grace period still count as racing;
    // the reaper removes them after the grace period and re-runs this check.
    const racers = [...room.players.values()].filter((p) => p.grid >= 0);
    if (racers.length === 0 || racers.every((p) => p.finished)) {
      const id = room.raceId;
      setTimeout(() => endRace(room, id), 1500);
    }
  };

  const finishPlayer = (room: Room, p: Player) => {
    p.finished = true;
    p.finishTime = Date.now() - room.startTime;
    const pos = standings(room).find((s) => s.pid === p.pid)?.pos ?? 0;
    if (p.socketId) io.to(p.socketId).emit("race:finish", { time: p.finishTime, pos });
    if (room.firstFinishAt === null) {
      room.firstFinishAt = Date.now();
      const id = room.raceId;
      setTimeout(() => endRace(room, id), FINISH_TIMEOUT);
      io.to(room.code).emit("race:notice", { text: `${p.name} finished! ${FINISH_TIMEOUT / 1000}s remaining`, ms: FINISH_TIMEOUT });
    }
    checkAllFinished(room);
  };

  const getCtx = (socket: Socket) => {
    const code = socket.data.code as string | undefined;
    const pid = socket.data.pid as string | undefined;
    if (!code || !pid) return null;
    const room = rooms.get(code);
    const p = room?.players.get(pid);
    if (!room || !p) return null;
    return { room, p };
  };

  const leaveCurrent = (socket: Socket) => {
    const ctx = getCtx(socket);
    if (ctx) removePlayer(ctx.room, ctx.p.pid);
    socket.data.code = undefined;
    socket.data.pid = undefined;
  };

  const makePlayer = (socket: Socket, d: any): Player => ({
    pid: crypto.randomBytes(4).toString("hex"),
    key: crypto.randomBytes(16).toString("hex"),
    socketId: socket.id,
    name: clean(d?.name, "Racer"),
    car: cleanCar(d?.car),
    color: cleanColor(d?.color),
    ready: false,
    connected: true,
    disconnectedAt: 0,
    joinedAt: Date.now(),
    device: d?.device === "mobile" ? "mobile" : "pc",
    s: [],
    lastStateAt: 0,
    lap: 1,
    nextCp: 1,
    finished: false,
    finishTime: null,
    grid: -1,
    ping: 0,
  });

  io.on("connection", (socket) => {
    socket.on("room:create", (d: any, ack?: (r: any) => void) => {
      if (typeof ack !== "function") return;
      leaveCurrent(socket);
      const code = newCode();
      const p = makePlayer(socket, d);
      p.ready = true;
      const room: Room = {
        code,
        hostPid: p.pid,
        maxPlayers: clampInt(d?.maxPlayers, 2, MAX_CAP, Math.min(8, MAX_CAP)),
        laps: clampInt(d?.laps, 1, 10, 3),
        state: "lobby",
        players: new Map([[p.pid, p]]),
        countdownEnd: 0,
        startTime: 0,
        firstFinishAt: null,
        raceId: 0,
        results: null,
        emptySince: null,
      };
      rooms.set(code, room);
      keyIndex.set(p.key, { code, pid: p.pid });
      socket.join(code);
      socket.data.code = code;
      socket.data.pid = p.pid;
      ack({ ok: true, code, pid: p.pid, key: p.key, room: roomInfo(room), maxCap: MAX_CAP });
    });

    socket.on("room:join", (d: any, ack?: (r: any) => void) => {
      if (typeof ack !== "function") return;
      const code = String(d?.code || "").toUpperCase().trim();
      const room = rooms.get(code);
      if (!room) return ack({ ok: false, error: `Room "${code}" not found. Check the code on the host screen.` });

      // Reconnection with a saved key
      if (typeof d?.key === "string") {
        const ref = keyIndex.get(d.key);
        if (ref && ref.code === code) {
          const p = room.players.get(ref.pid)!;
          if (p.socketId && p.socketId !== socket.id) io.sockets.sockets.get(p.socketId)?.disconnect(true);
          if (socket.data.code && socket.data.code !== code) leaveCurrent(socket);
          p.socketId = socket.id;
          p.connected = true;
          p.disconnectedAt = 0;
          room.emptySince = null;
          socket.join(code);
          socket.data.code = code;
          socket.data.pid = p.pid;
          ack({ ok: true, code, pid: p.pid, key: p.key, room: roomInfo(room), race: raceSnapshot(room, p), reconnected: true, maxCap: MAX_CAP });
          sendRoom(room);
          return;
        }
      }
      if (room.state !== "lobby" && room.state !== "results")
        return ack({ ok: false, error: "A race is in progress in this room. Wait for it to finish and try again." });
      if (room.players.size >= room.maxPlayers) return ack({ ok: false, error: `Room is full (${room.maxPlayers} players max).` });

      leaveCurrent(socket);
      const p = makePlayer(socket, d);
      room.players.set(p.pid, p);
      keyIndex.set(p.key, { code, pid: p.pid });
      room.emptySince = null;
      socket.join(code);
      socket.data.code = code;
      socket.data.pid = p.pid;
      ack({ ok: true, code, pid: p.pid, key: p.key, room: roomInfo(room), race: raceSnapshot(room, p), maxCap: MAX_CAP });
      sendRoom(room);
    });

    socket.on("room:leave", () => leaveCurrent(socket));

    socket.on("player:config", (d: any) => {
      const ctx = getCtx(socket);
      if (!ctx) return;
      const { room, p } = ctx;
      if (d?.name !== undefined) p.name = clean(d.name, p.name);
      if (room.state === "lobby" || room.state === "results") {
        if (d?.car !== undefined) p.car = cleanCar(d.car);
        if (d?.color !== undefined) p.color = cleanColor(d.color);
        if (typeof d?.ready === "boolean") p.ready = room.hostPid === p.pid ? true : d.ready;
      }
      sendRoom(room);
    });

    socket.on("room:settings", (d: any) => {
      const ctx = getCtx(socket);
      if (!ctx || ctx.room.hostPid !== ctx.p.pid) return;
      const { room } = ctx;
      if (room.state !== "lobby" && room.state !== "results") return;
      if (d?.laps !== undefined) room.laps = clampInt(d.laps, 1, 10, room.laps);
      if (d?.maxPlayers !== undefined) room.maxPlayers = clampInt(d.maxPlayers, Math.max(2, room.players.size), MAX_CAP, room.maxPlayers);
      sendRoom(room);
    });

    socket.on("race:start", (_d: any, ack?: (r: any) => void) => {
      const reply = typeof ack === "function" ? ack : () => {};
      const ctx = getCtx(socket);
      if (!ctx) return reply({ ok: false, error: "Not in a room" });
      const { room, p } = ctx;
      if (room.hostPid !== p.pid) return reply({ ok: false, error: "Only the host can start the race" });
      if (room.state !== "lobby" && room.state !== "results") return reply({ ok: false, error: "Race already running" });
      // drop disconnected players
      for (const q of [...room.players.values()]) if (!q.connected) removePlayer(room, q.pid);
      const notReady = [...room.players.values()].filter((q) => !q.ready && q.pid !== room.hostPid);
      if (notReady.length) return reply({ ok: false, error: `Waiting for: ${notReady.map((q) => q.name).join(", ")}` });

      const ordered = [...room.players.values()].sort((a, b) => a.joinedAt - b.joinedAt);
      ordered.forEach((q, i) => {
        q.grid = i;
        q.lap = 1;
        q.nextCp = 1;
        q.finished = false;
        q.finishTime = null;
        q.s = [];
      });
      room.state = "countdown";
      room.raceId++;
      room.firstFinishAt = null;
      room.results = null;
      room.countdownEnd = Date.now() + COUNTDOWN_MS;
      const id = room.raceId;
      io.to(room.code).emit("race:countdown", {
        ms: COUNTDOWN_MS,
        laps: room.laps,
        grid: Object.fromEntries(ordered.map((q) => [q.pid, q.grid])),
      });
      sendRoom(room);
      reply({ ok: true });
      setTimeout(() => {
        if (room.raceId !== id || room.state !== "countdown") return;
        room.state = "racing";
        room.startTime = Date.now();
        io.to(room.code).emit("race:go", { t: room.startTime });
        sendRoom(room);
      }, COUNTDOWN_MS);
    });

    socket.on("race:lobby", () => {
      const ctx = getCtx(socket);
      if (!ctx || ctx.room.hostPid !== ctx.p.pid) return;
      const { room } = ctx;
      if (room.state === "racing") endRace(room, room.raceId);
      room.state = "lobby";
      for (const q of room.players.values()) {
        q.grid = -1;
        q.ready = q.pid === room.hostPid;
      }
      io.to(room.code).emit("race:lobby", {});
      sendRoom(room);
    });

    // High-frequency vehicle state (volatile)
    socket.on("s", (arr: unknown) => {
      const ctx = getCtx(socket);
      if (!ctx || !Array.isArray(arr) || arr.length !== 8) return;
      for (const v of arr) if (typeof v !== "number" || !Number.isFinite(v)) return;
      const { room, p } = ctx;
      const now = Date.now();
      const prev = p.s;
      const dt = p.lastStateAt ? (now - p.lastStateAt) / 1000 : 1;
      p.s = arr as number[];
      p.lastStateAt = now;
      if (room.state !== "racing" || p.finished || p.grid < 0) return;
      if (prev.length) {
        const jump = Math.hypot(arr[0] - prev[0], arr[1] - prev[1]);
        if (jump > 130 * dt + 40) return; // reject teleports for checkpoint logic
      }
      const cp = CPS[p.nextCp];
      const dx = p.s[0] - cp[0];
      const dz = p.s[1] - cp[1];
      if (dx * dx + dz * dz < CP_R2) {
        if (p.nextCp === 0) {
          p.lap++;
          if (p.lap > room.laps) {
            p.nextCp = 1;
            finishPlayer(room, p);
            return;
          }
        }
        p.nextCp = (p.nextCp + 1) % NCP;
        socket.emit("race:cp", { lap: p.lap, nextCp: p.nextCp });
      }
    });

    socket.on("ping:check", (t: unknown, ack?: (t: unknown) => void) => {
      if (typeof ack === "function") ack(t);
    });
    socket.on("ping:rtt", (ms: unknown) => {
      const ctx = getCtx(socket);
      if (ctx && typeof ms === "number" && Number.isFinite(ms)) ctx.p.ping = Math.round(Math.min(9999, Math.max(0, ms)));
    });

    socket.on("disconnect", () => {
      const ctx = getCtx(socket);
      if (!ctx) return;
      const { room, p } = ctx;
      if (p.socketId !== socket.id) return;
      p.connected = false;
      p.socketId = null;
      p.disconnectedAt = Date.now();
      if (room.hostPid === p.pid) reassignHost(room);
      checkAllFinished(room);
      sendRoom(room);
    });
  });

  // Snapshots + standings + reaper
  let tick = 0;
  const loop = setInterval(() => {
    tick++;
    const now = Date.now();
    for (const room of rooms.values()) {
      if (room.state === "countdown" || room.state === "racing") {
        const p: (string | number)[][] = [];
        for (const q of room.players.values()) if (q.s.length === 8) p.push([q.pid, ...q.s.map((v) => Math.round(v * 100) / 100), q.connected ? 1 : 0]);
        io.to(room.code).volatile.emit("snap", { t: now, p });
        if (tick % 4 === 0) {
          io.to(room.code).emit("race:state", {
            standings: standings(room),
            elapsed: room.state === "racing" ? now - room.startTime : 0,
            state: room.state,
          });
        }
      }
      if (tick % 20 === 0) {
        let changed = false;
        for (const q of [...room.players.values()]) {
          if (q.connected) continue;
          const grace = room.state === "lobby" || room.state === "results" ? LOBBY_GRACE : RACE_GRACE;
          if (now - q.disconnectedAt > grace) {
            removePlayer(room, q.pid);
            changed = true;
          }
        }
        if (!rooms.has(room.code)) continue;
        const anyConnected = [...room.players.values()].some((q) => q.connected);
        if (!anyConnected) {
          room.emptySince ??= now;
          if (now - room.emptySince > 120_000) {
            for (const q of room.players.values()) keyIndex.delete(q.key);
            rooms.delete(room.code);
            continue;
          }
        }
        if (changed) sendRoom(room);
      }
    }
  }, TICK_MS);
  loop.unref?.();
}

export function realtimeStatus() {
  const g = globalThis as any;
  return {
    realtime: g.__raceRealtime ?? null,
    rooms: rooms.size,
    maxCap: MAX_CAP,
  };
}
