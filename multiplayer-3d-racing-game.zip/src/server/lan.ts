import os from "os";

export type LanAddress = { address: string; iface: string; score: number };

const VIRTUAL = /(vEthernet|docker|veth|br-|virbr|VirtualBox|VMware|vmnet|utun|tailscale|zerotier|Hyper-V|WSL|Loopback)/i;

/** Returns IPv4 LAN addresses of this machine, best candidates first. */
export function getLanAddresses(): LanAddress[] {
  const out: LanAddress[] = [];
  const ifs = os.networkInterfaces();
  for (const [iface, list] of Object.entries(ifs)) {
    for (const a of list ?? []) {
      if (a.family !== "IPv4" || a.internal) continue;
      let score = 0;
      if (a.address.startsWith("192.168.")) score += 30;
      else if (a.address.startsWith("10.")) score += 20;
      else if (/^172\.(1[6-9]|2\d|3[01])\./.test(a.address)) score += 10;
      if (/wi-?fi|wlan|wlp|en0|eth0|ethernet/i.test(iface)) score += 5;
      if (VIRTUAL.test(iface)) score -= 40;
      out.push({ address: a.address, iface, score });
    }
  }
  return out.sort((a, b) => b.score - a.score);
}
