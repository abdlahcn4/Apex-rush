# 🏁 APEX RUSH — 3D Sunset Highway Racing (Single Player + LAN Multiplayer)

A complete Three.js racing game with a Node.js + Socket.IO LAN multiplayer server.
PC players (keyboard) and phone players (touchscreen) race together in the **same real-time session**.

## Requirements
- Node.js 18+ (20/22 recommended)
- PC and phones on the **same Wi-Fi network**
- PostgreSQL (optional — only used for the LAN leaderboard; the game works without it)

## Install & start (host PC)
```bash
npm install
npm run build
node server.js          # production host (recommended)
# or: npm run start     # also works — multiplayer attaches automatically
# dev mode: node server.js --dev
```
The console prints the real LAN addresses, e.g.
```
On this PC:  http://localhost:3000
On phones:   http://<your-LAN-IP>:3000
```
Environment variables: `PORT` (default 3000), `MAX_PLAYERS` (room cap, default 8, max 16), `DATABASE_URL` (leaderboard).

### Leaderboard database (optional)
Set `DATABASE_URL` in `.env`, then run `npx drizzle-kit push`.

## Playing on LAN
1. **PC host**: open `http://localhost:3000` → **LAN MULTIPLAYER** → **HOST A ROOM** → choose max players & laps → **CREATE ROOM**.
   The lobby shows the 4-letter **room code**, the detected **LAN address** and a **QR code**.
2. **Phone**: open the LAN address shown (or scan the QR) → **LAN MULTIPLAYER → JOIN A ROOM** → enter the code.
3. Pick a car & colour, tap **READY UP**. The host presses **START RACE**.
4. If a phone briefly loses Wi-Fi, it reconnects automatically and keeps its lap/checkpoint progress (60 s grace; page reload also rejoins).

Windows firewall: allow Node.js on **Private networks** if phones cannot load the page.

## Controls
| PC | Mobile |
|---|---|
| W / ↑ accelerate | GAS pedal |
| S / ↓ brake / reverse | BRAKE pedal |
| A D / ← → steer | ◀ ▶ buttons or steering wheel (Settings) |
| Space handbrake (drift) | HANDBRAKE |
| C camera | 🎥 button |
| R reset car · Esc pause | ❚❚ button |

## Game modes
- **Free Drive**: endless, procedurally streamed highway with traffic.
- **Time Trial**: 3 laps of Sunset Ring; personal bests for best lap and total time.
- **AI Race**: 5 AI opponents; your finishing position earns coins.
- **Traffic Racing**: 120 s; your score comes from speed, near misses and combos.
- **Checkpoint Challenge**: reach each checkpoint gate before the timer runs out.
- **LAN Race**: real players. The server owns checkpoints, laps, positions, countdown and results.

## Architecture
| File | Purpose |
|---|---|
| `server.js` | LAN host launcher (Next.js + Socket.IO on one port, prints LAN IPs) |
| `src/server/realtime.ts` | Authoritative multiplayer server: rooms, codes, countdown, checkpoint validation, standings, results, reconnection |
| `src/instrumentation.ts` | Attaches the Socket.IO server to the running HTTP server |
| `public/index.html`, `public/style.css` | Game UI |
| `public/js/game.js` | Main game: renderer, modes, camera, HUD wiring, garage, settings |
| `public/js/multiplayer.js` | Socket.IO client, lobby, 30 Hz state sending, 100 ms interpolation buffer |
| `public/js/track.js` | Sky shader (dynamic sun and clouds), circuit and endless highway, scenery |
| `public/js/cars.js` | Procedural sports cars, traffic, name tags |
| `public/js/vehicle.js` | Arcade drift physics, gears, suspension, collisions |
| `public/js/ai.js` | AI racers and highway traffic |
| `public/js/trackdata.json` | Track and checkpoints, used by both client and server |

Progress (coins, cars, upgrades, paint, personal bests, settings) is saved in `localStorage`.
