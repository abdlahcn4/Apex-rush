import { fmtTime } from './save.js';

const $ = (id) => document.getElementById(id);

export class HUD {
  constructor() {
    this.el = $('hud');
    this.board = $('hud-board');
    this.sc = $('speedo-c').getContext('2d');
    this.mm = $('minimap');
    this.mc = this.mm.getContext('2d');
    this.fx = $('fx');
    this.fc = this.fx.getContext('2d');
    this.toastT = 0;
    this.lastBoard = '';
    this.lines = [];
    for (let i = 0; i < 60; i++) this.lines.push({ a: Math.random() * Math.PI * 2, r: Math.random(), s: 0.5 + Math.random() });
    this.trackPath = null;
    addEventListener('resize', () => this.resizeFx());
    this.resizeFx();
  }
  resizeFx() {
    this.fx.width = Math.round(innerWidth * 0.75);
    this.fx.height = Math.round(innerHeight * 0.75);
  }
  show(on) {
    this.el.hidden = !on;
    if (!on) {
      this.fc.clearRect(0, 0, this.fx.width, this.fx.height);
      this.countdown('');
      this.big('');
    }
  }
  setVisible(id, on) { const e = $(id); if (e) e.style.display = on ? '' : 'none'; }
  top({ pos, lap, time, timeLabel = 'TIME', lapLabel = 'LAP', extraLabel = '', extra = '' }) {
    this.setVisible('hud-pos-box', pos != null);
    if (pos != null) $('hud-pos').textContent = pos;
    this.setVisible('hud-lap-box', lap != null);
    if (lap != null) { $('hud-lap').textContent = lap; $('hud-lap-l').textContent = lapLabel; }
    $('hud-time').textContent = typeof time === 'number' ? fmtTime(time) : time;
    $('hud-time-l').textContent = timeLabel;
    this.setVisible('hud-extra-box', !!extraLabel);
    $('hud-extra-l').textContent = extraLabel;
    $('hud-extra').textContent = extra;
  }
  setBoard(rows, header) {
    const html = (header ? `<div class="hdr">${header}</div>` : '') + rows.map((r) =>
      `<div class="r${r.me ? ' me' : ''}${r.off ? ' off' : ''}"><span class="p">${r.pos}</span><span class="c" style="background:${r.color}"></span><span class="n">${esc(r.name)}</span><span class="g">${r.info ?? ''}</span></div>`).join('');
    if (html !== this.lastBoard) { this.board.innerHTML = html; this.lastBoard = html; }
  }
  speed(kmh, gear, rpmFrac, maxKmh) {
    $('spd').textContent = Math.round(kmh);
    $('gear').textContent = gear;
    const g = this.sc, W = 220, cx = 110, cy = 110, R = 96;
    g.clearRect(0, 0, W, W);
    const a0 = Math.PI * 0.75, sweep = Math.PI * 1.5;
    const max = Math.ceil(maxKmh / 40) * 40;
    g.lineCap = 'round';
    g.beginPath(); g.arc(cx, cy, R, a0, a0 + sweep); g.strokeStyle = 'rgba(10,14,26,0.65)'; g.lineWidth = 18; g.stroke();
    const f = Math.min(1, kmh / max);
    const grad = g.createLinearGradient(0, W, W, 0);
    grad.addColorStop(0, '#1fa2ff'); grad.addColorStop(0.6, '#ffd23f'); grad.addColorStop(1, '#ff3b5c');
    g.beginPath(); g.arc(cx, cy, R, a0, a0 + sweep * Math.max(0.001, f)); g.strokeStyle = grad; g.lineWidth = 10; g.stroke();
    g.beginPath(); g.arc(cx, cy, R - 16, a0, a0 + sweep * Math.min(1, rpmFrac)); g.strokeStyle = rpmFrac > 0.88 ? '#ff3b5c' : 'rgba(255,255,255,0.55)'; g.lineWidth = 4; g.stroke();
    g.fillStyle = '#cfd8ea'; g.font = 'bold 12px Segoe UI, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle';
    for (let v = 0; v <= max; v += 20) {
      const a = a0 + sweep * (v / max);
      const major = v % 40 === 0;
      g.beginPath();
      g.moveTo(cx + Math.cos(a) * (R - 6), cy + Math.sin(a) * (R - 6));
      g.lineTo(cx + Math.cos(a) * (R + (major ? 6 : 2)), cy + Math.sin(a) * (R + (major ? 6 : 2)));
      g.strokeStyle = '#fff'; g.lineWidth = major ? 2 : 1; g.stroke();
      if (major && max <= 400) g.fillText(String(v), cx + Math.cos(a) * (R - 28), cy + Math.sin(a) * (R - 28));
    }
  }
  countdown(t) {
    const c = $('countdown');
    c.textContent = t;
    c.className = t === 'GO!' ? 'go' : '';
  }
  big(t, color) { const b = $('bigmsg'); b.textContent = t; b.style.color = color || '#fff'; }
  toast(text, ms = 1600) {
    const t = $('toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(this.toastT);
    this.toastT = setTimeout(() => t.classList.remove('show'), ms);
  }
  fps(v) { $('fps').textContent = v ? `${v} FPS` : ''; }
  net(text) { $('net-status').textContent = text || ''; }

  setTrack(track) {
    this.trackPath = null;
    if (track.kind !== 'circuit') return;
    const b = track.bounds;
    const size = Math.max(b.maxX - b.minX, b.maxZ - b.minZ);
    this.mmScale = 170 / size;
    this.mmCx = (b.minX + b.maxX) / 2;
    this.mmCz = (b.minZ + b.maxZ) / 2;
    this.trackPath = track.samples.filter((_, i) => i % 6 === 0).map((s) => [s.x, s.z]);
  }
  minimap(track, me, cars, extras = []) {
    const g = this.mc, W = 200;
    g.clearRect(0, 0, W, W);
    g.save();
    g.beginPath(); g.arc(100, 100, 98, 0, Math.PI * 2); g.clip();
    if (this.trackPath) {
      // north-up full circuit (mirror X so screen-right matches driver-right when heading +Z)
      const tx = (x) => 100 - (x - this.mmCx) * this.mmScale;
      const tz = (z) => 100 - (z - this.mmCz) * this.mmScale;
      g.beginPath();
      this.trackPath.forEach(([x, z], i) => (i ? g.lineTo(tx(x), tz(z)) : g.moveTo(tx(x), tz(z))));
      g.closePath();
      g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 5; g.stroke();
      g.strokeStyle = 'rgba(40,46,60,1)'; g.lineWidth = 2.5; g.stroke();
      const s0 = track.samples[0];
      g.fillStyle = '#fff'; g.fillRect(tx(s0.x) - 4, tz(s0.z) - 1.5, 8, 3);
      for (const c of cars) dot(g, tx(c.x), tz(c.z), c.color, 4.5);
      for (const e of extras) dot(g, tx(e.x), tz(e.z), e.color, 3);
      arrow(g, tx(me.x), tz(me.z), -me.h, '#ff7a18');
    } else {
      // local heading-up view (220 m radius)
      const sc = 98 / 220;
      const ch = Math.cos(me.h), sh = Math.sin(me.h);
      const toS = (x, z) => {
        const dx = x - me.x, dz = z - me.z;
        const lx = -(dx * ch - dz * sh); // right
        const lz = dx * sh + dz * ch; // forward
        return [100 + lx * sc, 100 - lz * sc];
      };
      for (const side of [-1, 1]) {
        g.beginPath();
        for (let s = me.z - 200; s <= me.z + 260; s += 20) {
          const p = track.pointAt(s, side * 11);
          const [X, Y] = toS(p.x, p.z);
          s === me.z - 200 ? g.moveTo(X, Y) : g.lineTo(X, Y);
        }
        g.strokeStyle = 'rgba(255,255,255,0.7)'; g.lineWidth = 2; g.stroke();
      }
      for (const c of cars) { const [X, Y] = toS(c.x, c.z); dot(g, X, Y, c.color, 3.5); }
      for (const e of extras) { const [X, Y] = toS(e.x, e.z); dot(g, X, Y, e.color, 5); }
      arrow(g, 100, 100, 0, '#ff7a18');
    }
    g.restore();
  }
  speedLines(speedKmh, enabled) {
    const g = this.fc, W = this.fx.width, H = this.fx.height;
    g.clearRect(0, 0, W, H);
    if (!enabled || speedKmh < 130) return;
    const k = Math.min(1, (speedKmh - 130) / 170);
    const cx = W / 2, cy = H * 0.45, R = Math.hypot(W, H) / 2;
    g.strokeStyle = `rgba(255,255,255,${0.08 + k * 0.22})`;
    g.lineWidth = 1.5;
    g.beginPath();
    for (const l of this.lines) {
      l.r += l.s * 0.04 * (0.5 + k);
      if (l.r > 1) { l.r = 0.35 + Math.random() * 0.2; l.a = Math.random() * Math.PI * 2; }
      const r0 = R * l.r, r1 = R * (l.r + 0.08 + k * 0.1);
      g.moveTo(cx + Math.cos(l.a) * r0, cy + Math.sin(l.a) * r0);
      g.lineTo(cx + Math.cos(l.a) * r1, cy + Math.sin(l.a) * r1);
    }
    g.stroke();
    const vg = g.createRadialGradient(cx, cy, R * 0.45, cx, cy, R);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, `rgba(0,0,0,${k * 0.35})`);
    g.fillStyle = vg;
    g.fillRect(0, 0, W, H);
  }
}
function dot(g, x, y, c, r) { g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fillStyle = c; g.fill(); g.strokeStyle = '#000a'; g.lineWidth = 1; g.stroke(); }
function arrow(g, x, y, a, c) {
  g.save(); g.translate(x, y); g.rotate(a);
  g.beginPath(); g.moveTo(0, -8); g.lineTo(6, 6); g.lineTo(0, 3); g.lineTo(-6, 6); g.closePath();
  g.fillStyle = c; g.fill(); g.strokeStyle = '#fff'; g.lineWidth = 1.5; g.stroke(); g.restore();
}
export function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
