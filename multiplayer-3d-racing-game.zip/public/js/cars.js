import * as THREE from 'three';

/* Car catalogue. top = m/s, accel = m/s², brake = m/s², handling = multiplier */
export const CAR_SPECS = {
  vortex: { id: 'vortex', name: 'Vortex GT', tag: 'STARTER SUPERCAR', tier: 1, price: 0, top: 70, accel: 12, brake: 26, handling: 1.0, color: '#2ecc40',
    body: { L: 4.5, W: 2.0, wb: 1.35, wr: 0.36, noseY: 0.52, hoodY: 0.74, beltY: 0.86, tailY: 0.96, cabF: 0.75, roofF: -0.05, roofB: -0.85, cabB: -1.55, cabTop: 1.18, wing: 1 } },
  falcon: { id: 'falcon', name: 'Falcon RS', tag: 'TRACK COUPE', tier: 2, price: 2500, top: 75, accel: 13, brake: 28, handling: 1.06, color: '#e63946',
    body: { L: 4.55, W: 1.95, wb: 1.38, wr: 0.36, noseY: 0.56, hoodY: 0.8, beltY: 0.9, tailY: 1.0, cabF: 0.6, roofF: -0.15, roofB: -1.0, cabB: -1.65, cabTop: 1.3, wing: 2 } },
  titan: { id: 'titan', name: 'Titan V8', tag: 'MUSCLE', tier: 2, price: 4000, top: 79, accel: 14.5, brake: 25, handling: 0.94, color: '#f4a261',
    body: { L: 4.8, W: 2.02, wb: 1.45, wr: 0.38, noseY: 0.72, hoodY: 0.92, beltY: 0.96, tailY: 0.97, cabF: 0.3, roofF: -0.3, roofB: -1.15, cabB: -1.65, cabTop: 1.36, wing: 1, scoop: true } },
  nimbus: { id: 'nimbus', name: 'Nimbus E-GT', tag: 'ELECTRIC GT', tier: 3, price: 6500, top: 81, accel: 17, brake: 29, handling: 1.08, color: '#f1faee',
    body: { L: 4.7, W: 1.98, wb: 1.42, wr: 0.37, noseY: 0.56, hoodY: 0.78, beltY: 0.88, tailY: 0.98, cabF: 0.9, roofF: 0.0, roofB: -1.2, cabB: -2.0, cabTop: 1.3, wing: 0 } },
  raptor: { id: 'raptor', name: 'Raptor X', tag: 'HYPERCAR', tier: 4, price: 10000, top: 88, accel: 17.5, brake: 31, handling: 1.12, color: '#ffbe0b',
    body: { L: 4.6, W: 2.05, wb: 1.38, wr: 0.36, noseY: 0.42, hoodY: 0.66, beltY: 0.8, tailY: 0.92, cabF: 0.85, roofF: 0.15, roofB: -0.6, cabB: -1.4, cabTop: 1.1, wing: 2 } },
  phantom: { id: 'phantom', name: 'Phantom LM', tag: 'LE MANS PROTOTYPE', tier: 5, price: 16000, top: 95, accel: 19, brake: 34, handling: 1.18, color: '#7b2ff7',
    body: { L: 4.9, W: 2.05, wb: 1.5, wr: 0.36, noseY: 0.38, hoodY: 0.6, beltY: 0.78, tailY: 0.96, cabF: 0.7, roofF: 0.1, roofB: -0.5, cabB: -1.0, cabTop: 1.08, wing: 2, fin: true } },
};
export const CAR_ORDER = ['vortex', 'falcon', 'titan', 'nimbus', 'raptor', 'phantom'];
export const PAINTS = ['#2ecc40', '#e63946', '#1fa2ff', '#ffbe0b', '#f4a261', '#7b2ff7', '#f1faee', '#111318', '#ff5fa2', '#00d1b2', '#8d99ae', '#c0392b'];
export const MAX_UPGRADE = 5;

export function carStats(id, up = { engine: 0, brakes: 0, handling: 0 }) {
  const s = CAR_SPECS[id] || CAR_SPECS.vortex;
  return {
    top: s.top * (1 + 0.035 * up.engine),
    accel: s.accel * (1 + 0.07 * up.engine),
    brake: s.brake * (1 + 0.1 * up.brakes),
    handling: s.handling * (1 + 0.045 * up.handling),
  };
}
export function upgradeCost(id, level) {
  const s = CAR_SPECS[id];
  return Math.round((200 + 150 * s.tier) * (level + 1));
}

export const QUALITY = { low: 0, medium: 1, high: 2, ultra: 3 };

/* ---------------- shared materials ---------------- */
const shared = {};
function mats() {
  if (shared.glass) return shared;
  shared.glass = new THREE.MeshStandardMaterial({ color: 0x0b1018, metalness: 0.9, roughness: 0.08, envMapIntensity: 1.6 });
  shared.tire = new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.92 });
  shared.rim = new THREE.MeshStandardMaterial({ color: 0xc8ccd2, metalness: 1, roughness: 0.22 });
  shared.darkRim = new THREE.MeshStandardMaterial({ color: 0x2a2d33, metalness: 0.9, roughness: 0.3 });
  shared.black = new THREE.MeshStandardMaterial({ color: 0x0c0c0e, roughness: 0.55, metalness: 0.2 });
  shared.carbon = new THREE.MeshStandardMaterial({ color: 0x1a1c20, roughness: 0.35, metalness: 0.6 });
  shared.chrome = new THREE.MeshStandardMaterial({ color: 0xdddddd, metalness: 1, roughness: 0.1 });
  shared.head = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff4e0, emissiveIntensity: 2.2 });
  shared.caliper = new THREE.MeshStandardMaterial({ color: 0xd62828, roughness: 0.4, metalness: 0.3 });
  shared.disc = new THREE.MeshStandardMaterial({ color: 0x777777, metalness: 0.8, roughness: 0.35 });
  return shared;
}

export function makePaint(color, q) {
  if (q >= 2) return new THREE.MeshPhysicalMaterial({ color, metalness: 0.55, roughness: 0.3, clearcoat: 1, clearcoatRoughness: 0.06, envMapIntensity: 1.2 });
  return new THREE.MeshStandardMaterial({ color, metalness: 0.5, roughness: 0.34, envMapIntensity: 1.1 });
}

let blobTex = null;
function blobTexture() {
  if (blobTex) return blobTex;
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(64, 64, 10, 64, 64, 64);
  gr.addColorStop(0, 'rgba(0,0,0,0.75)');
  gr.addColorStop(0.6, 'rgba(0,0,0,0.4)');
  gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr;
  g.fillRect(0, 0, 128, 128);
  blobTex = new THREE.CanvasTexture(c);
  return blobTex;
}
export function makeBlobShadow(w, l) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, l), new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, depthWrite: false }));
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.04;
  m.renderOrder = 1;
  return m;
}

function box(w, h, d, mat, x, y, z) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.position.set(x, y, z);
  return m;
}

function makeWheel(wr, q, dark) {
  const M = mats();
  const pivot = new THREE.Group();
  const spin = new THREE.Group();
  pivot.add(spin);
  const seg = q >= 2 ? 26 : 14;
  const tire = new THREE.Mesh(new THREE.CylinderGeometry(wr, wr, 0.3, seg), M.tire);
  tire.rotation.z = Math.PI / 2;
  spin.add(tire);
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(wr * 0.68, wr * 0.68, 0.31, seg), dark ? M.darkRim : M.rim);
  rim.rotation.z = Math.PI / 2;
  spin.add(rim);
  if (q >= 1) {
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(wr * 0.62, wr * 0.62, 0.315, seg), M.black);
    hub.rotation.z = Math.PI / 2;
    spin.add(hub);
    for (let i = 0; i < 5; i++) {
      const sp = new THREE.Mesh(new THREE.BoxGeometry(0.33, wr * 1.22, 0.07), dark ? M.darkRim : M.rim);
      sp.rotation.x = (i / 5) * Math.PI;
      spin.add(sp);
    }
    const cal = box(0.12, 0.18, 0.2, M.caliper, 0, wr * 0.32, -0.1);
    pivot.add(cal);
  }
  return { pivot, spin };
}

/** Builds a detailed procedural sports car. Forward = +Z, ground at y=0. */
export function buildCar(id, color, q = 2) {
  const spec = CAR_SPECS[id] || CAR_SPECS.vortex;
  const b = spec.body;
  const M = mats();
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const paint = makePaint(color, q);
  const hl = b.L / 2, W = b.W, wb = b.wb, wr = b.wr, ar = wr + 0.1, y0 = 0.3;

  // --- main shell (side profile extruded across the width)
  const s = new THREE.Shape();
  s.moveTo(-hl, y0 + 0.06);
  s.lineTo(-wb - ar, y0);
  s.absarc(-wb, wr, ar, Math.PI, 0, true);
  s.lineTo(wb - ar, y0);
  s.absarc(wb, wr, ar, Math.PI, 0, true);
  s.lineTo(hl, y0 + 0.03);
  s.quadraticCurveTo(hl + 0.1, b.noseY * 0.7, hl, b.noseY);
  s.quadraticCurveTo(hl - 0.6, b.hoodY, b.cabF, b.beltY);
  s.lineTo(b.cabB, b.beltY + 0.03);
  s.quadraticCurveTo(-hl + 0.3, b.tailY + 0.02, -hl, b.tailY - 0.06);
  s.lineTo(-hl - 0.03, y0 + 0.06);
  const depth = W - 0.24;
  const shellGeo = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: true, bevelThickness: 0.12, bevelSize: 0.08, bevelSegments: q >= 2 ? 4 : 2, curveSegments: q >= 2 ? 14 : 7 });
  shellGeo.translate(0, 0, -depth / 2);
  shellGeo.rotateY(-Math.PI / 2);
  const shell = new THREE.Mesh(shellGeo, paint);
  body.add(shell);

  // --- cabin glass
  const cs = new THREE.Shape();
  cs.moveTo(b.cabF + 0.05, b.beltY - 0.02);
  cs.quadraticCurveTo(b.roofF + 0.3, b.cabTop - 0.02, b.roofF, b.cabTop);
  cs.lineTo(b.roofB, b.cabTop);
  cs.quadraticCurveTo(b.cabB + 0.2, b.cabTop - 0.06, b.cabB - 0.05, b.beltY + 0.02);
  cs.lineTo(b.cabF + 0.05, b.beltY - 0.02);
  const cabD = W * 0.78 - 0.2;
  const cabGeo = new THREE.ExtrudeGeometry(cs, { depth: cabD, bevelEnabled: true, bevelThickness: 0.1, bevelSize: 0.06, bevelSegments: 2, curveSegments: 8 });
  cabGeo.translate(0, 0, -cabD / 2);
  cabGeo.rotateY(-Math.PI / 2);
  body.add(new THREE.Mesh(cabGeo, M.glass));
  // painted roof panel
  const roofLen = Math.max(0.3, b.roofF - b.roofB);
  const roof = box(W * 0.72, 0.05, roofLen, paint, 0, b.cabTop + 0.085, (b.roofF + b.roofB) / 2);
  body.add(roof);

  // --- lights
  const head = M.head;
  for (const sx of [-1, 1]) {
    const hlm = box(0.46, 0.09, 0.22, head, sx * W * 0.32, b.noseY - 0.03, hl - 0.01);
    hlm.rotation.x = -0.25;
    body.add(hlm);
    body.add(box(0.12, 0.05, 0.3, M.black, sx * (W / 2 + 0.02), b.beltY + 0.12, b.cabF - 0.15)); // mirror arm
    body.add(box(0.2, 0.12, 0.08, paint, sx * (W / 2 + 0.1), b.beltY + 0.16, b.cabF - 0.15)); // mirror
    body.add(box(0.08, 0.14, b.L * 0.5, M.carbon, sx * (W / 2 + 0.02), y0 + 0.07, 0)); // side skirt
  }
  const tail = new THREE.MeshStandardMaterial({ color: 0x550000, emissive: 0xff1020, emissiveIntensity: 0.9 });
  body.add(box(W * 0.86, 0.08, 0.06, tail, 0, b.tailY - 0.17, -hl - 0.12));
  for (const sx of [-1, 1]) body.add(box(0.4, 0.13, 0.06, tail, sx * W * 0.34, b.tailY - 0.2, -hl - 0.13));
  body.add(box(W * 0.62, 0.16, 0.1, M.black, 0, 0.42, hl + 0.1)); // grille
  body.add(box(W * 0.8, 0.14, 0.2, M.carbon, 0, 0.36, -hl - 0.06)); // diffuser
  for (const sx of [-1, 1]) {
    const ex = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.18, 10), M.chrome);
    ex.rotation.x = Math.PI / 2;
    ex.position.set(sx * 0.32, 0.4, -hl - 0.14);
    body.add(ex);
  }
  // --- aero
  if (b.wing === 1) body.add(box(W * 0.84, 0.05, 0.22, M.carbon, 0, b.tailY + 0.03, -hl + 0.15));
  if (b.wing === 2) {
    const wy = b.tailY + 0.32;
    body.add(box(W * 0.98, 0.05, 0.42, M.carbon, 0, wy, -hl + 0.32));
    for (const sx of [-1, 1]) {
      body.add(box(0.05, 0.32, 0.1, M.carbon, sx * W * 0.28, wy - 0.17, -hl + 0.32));
      body.add(box(0.04, 0.2, 0.5, M.carbon, sx * W * 0.49, wy + 0.02, -hl + 0.32));
    }
  }
  if (b.scoop) body.add(box(0.6, 0.12, 0.8, M.black, 0, b.hoodY + 0.08, hl - 1.0));
  if (b.fin) body.add(box(0.04, 0.34, 1.4, paint, 0, b.tailY + 0.1, -hl + 0.95));
  if (q >= 1) {
    // racing stripe on lighter cars
    const stripe = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.4, metalness: 0.3 });
    body.add(box(0.28, 0.01, roofLen, stripe, 0, b.cabTop + 0.115, (b.roofF + b.roofB) / 2));
  }

  // --- wheels (front = +Z)
  const wheels = [];
  const dark = spec.tier % 2 === 0;
  for (const [sx, sz, front] of [[-1, 1, true], [1, 1, true], [-1, -1, false], [1, -1, false]]) {
    const w = makeWheel(wr, q, dark);
    w.pivot.position.set(sx * (W / 2 - 0.13), wr, sz * wb);
    w.front = front;
    root.add(w.pivot);
    wheels.push(w);
  }
  const shadow = makeBlobShadow(W * 1.35, b.L * 1.15);
  root.add(shadow);

  root.traverse((o) => {
    if (o.isMesh && o !== shadow) {
      o.castShadow = q >= 2;
      o.receiveShadow = false;
    }
  });
  return { root, body, wheels, paint, tail, spec, wr, setColor: (c) => paint.color.set(c) };
}

/* ---------------- traffic vehicles ---------------- */
const TRAFFIC_TYPES = {
  sedan: { L: 4.4, W: 1.85, H: 0.75, cabH: 0.55, cabL: 2.2, cabZ: -0.2 },
  suv: { L: 4.7, W: 1.95, H: 0.95, cabH: 0.65, cabL: 2.8, cabZ: -0.4 },
  van: { L: 5.2, W: 2.0, H: 1.5, cabH: 0.6, cabL: 1.2, cabZ: 1.6 },
  truck: { L: 9.5, W: 2.4, H: 2.9, cabH: 0, cabL: 0, cabZ: 0 },
};
export const TRAFFIC_COLORS = ['#d9d9d9', '#3b3f48', '#8a1c1c', '#1d3557', '#f1f1f1', '#6c757d', '#2a9d8f', '#e9c46a', '#264653', '#b5838d'];
const geoCache = {};
const tMatCache = {};
function tMat(color) {
  return (tMatCache[color] ??= new THREE.MeshStandardMaterial({ color, metalness: 0.4, roughness: 0.45 }));
}

export function buildTraffic(type, color, q) {
  const t = TRAFFIC_TYPES[type];
  const M = mats();
  const root = new THREE.Group();
  const key = type;
  if (!geoCache[key]) {
    geoCache[key] = {
      body: new THREE.BoxGeometry(t.W, t.H, t.L),
      cab: t.cabH ? new THREE.BoxGeometry(t.W * 0.86, t.cabH, t.cabL) : null,
      wheel: new THREE.CylinderGeometry(type === 'truck' ? 0.5 : 0.34, type === 'truck' ? 0.5 : 0.34, 0.28, 12).rotateZ(Math.PI / 2),
      light: new THREE.BoxGeometry(0.4, 0.14, 0.05),
    };
  }
  const G = geoCache[key];
  const wr = type === 'truck' ? 0.5 : 0.34;
  const mat = tMat(color);
  if (type === 'truck') {
    const trailer = new THREE.Mesh(new THREE.BoxGeometry(t.W, 2.6, 7.0), tMat('#e8e8e8'));
    trailer.position.set(0, wr + 1.45, -1.2);
    root.add(trailer);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(t.W, 2.2, 2.2), mat);
    cab.position.set(0, wr + 1.2, 3.55);
    root.add(cab);
    const ws = new THREE.Mesh(new THREE.BoxGeometry(t.W * 0.9, 0.9, 0.05), M.glass);
    ws.position.set(0, wr + 1.75, 4.66);
    root.add(ws);
  } else {
    const b = new THREE.Mesh(G.body, mat);
    b.position.y = wr + t.H / 2 - 0.05;
    root.add(b);
    if (G.cab) {
      const c = new THREE.Mesh(G.cab, M.glass);
      c.position.set(0, wr + t.H + t.cabH / 2 - 0.06, t.cabZ);
      root.add(c);
    }
  }
  const tail = new THREE.MeshStandardMaterial({ color: 0x440000, emissive: 0xff2020, emissiveIntensity: 1.2 });
  const hz = t.L / 2;
  for (const sx of [-1, 1]) {
    const l = new THREE.Mesh(G.light, tail);
    l.position.set(sx * (t.W / 2 - 0.3), wr + 0.55, -hz - 0.03);
    root.add(l);
    const h = new THREE.Mesh(G.light, M.head);
    h.position.set(sx * (t.W / 2 - 0.3), wr + 0.45, hz + 0.03);
    root.add(h);
    for (const z of type === 'truck' ? [3.6, -2.5, -4.0] : [hz - 0.95, -hz + 0.95]) {
      const w = new THREE.Mesh(G.wheel, M.tire);
      w.position.set(sx * (t.W / 2 - 0.12), wr, z);
      root.add(w);
    }
  }
  root.add(makeBlobShadow(t.W * 1.3, t.L * 1.1));
  if (q >= 2) root.traverse((o) => { if (o.isMesh && o.geometry.type !== 'PlaneGeometry') o.castShadow = true; });
  return { root, L: t.L, W: t.W, type };
}
export const TRAFFIC_LIST = ['sedan', 'sedan', 'sedan', 'suv', 'suv', 'van', 'truck'];

/* ---------------- name tags ---------------- */
export function makeNameTag(name, color = '#ff7a18', sub = '') {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 128;
  const g = c.getContext('2d');
  const draw = (n, s) => {
    g.clearRect(0, 0, 512, 128);
    g.font = 'italic 900 46px Segoe UI, Roboto, Arial';
    const w = Math.min(470, g.measureText(n).width + 70);
    const x = 256 - w / 2;
    g.fillStyle = 'rgba(10,14,26,0.82)';
    g.beginPath();
    if (g.roundRect) g.roundRect(x, 24, w, 64, 14); else g.rect(x, 24, w, 64);
    g.fill();
    g.fillStyle = color;
    g.fillRect(x, 24, 12, 64);
    g.fillStyle = '#fff';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(n, 256 + 6, 57, 420);
    if (s) {
      g.font = '700 26px Segoe UI, Roboto, Arial';
      g.fillStyle = '#ffd23f';
      g.fillText(s, 256, 108);
    }
  };
  draw(name, sub);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: true, transparent: true, fog: false, sizeAttenuation: false }));
  sp.scale.set(0.2, 0.05, 1);
  sp.position.y = 2.3;
  sp.renderOrder = 5;
  sp.userData.update = (n, s) => { draw(n, s); tex.needsUpdate = true; };
  return sp;
}
