/* Procedural WebAudio sound: engine, tyre screech, wind, impacts, beeps */
export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.running = false;
    this.vol = 0.7;
    this.engineVol = 0.8;
  }
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.vol;
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 2;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }
  setVolume(master, engine) {
    this.vol = master;
    this.engineVol = engine;
    if (this.master) this.master.gain.value = master;
  }
  startEngine() {
    if (!this.ctx || this.running) return;
    const c = this.ctx;
    this.eGain = c.createGain();
    this.eGain.gain.value = 0;
    this.filter = c.createBiquadFilter();
    this.filter.type = 'lowpass';
    this.filter.Q.value = 3;
    this.o1 = c.createOscillator(); this.o1.type = 'sawtooth';
    this.o2 = c.createOscillator(); this.o2.type = 'square';
    this.o3 = c.createOscillator(); this.o3.type = 'sine';
    const g2 = c.createGain(); g2.gain.value = 0.35;
    const g3 = c.createGain(); g3.gain.value = 0.6;
    this.o1.connect(this.filter);
    this.o2.connect(g2).connect(this.filter);
    this.o3.connect(g3).connect(this.filter);
    this.filter.connect(this.eGain).connect(this.master);
    // screech
    this.sSrc = c.createBufferSource(); this.sSrc.buffer = this.noise; this.sSrc.loop = true;
    const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1500; bp.Q.value = 4;
    this.sGain = c.createGain(); this.sGain.gain.value = 0;
    this.sSrc.connect(bp).connect(this.sGain).connect(this.master);
    // wind
    this.wSrc = c.createBufferSource(); this.wSrc.buffer = this.noise; this.wSrc.loop = true;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 600;
    this.wGain = c.createGain(); this.wGain.gain.value = 0;
    this.wSrc.connect(lp).connect(this.wGain).connect(this.master);
    for (const o of [this.o1, this.o2, this.o3, this.sSrc, this.wSrc]) o.start();
    this.running = true;
  }
  stopEngine() {
    if (!this.running) return;
    for (const o of [this.o1, this.o2, this.o3, this.sSrc, this.wSrc]) { try { o.stop(); } catch { /* */ } }
    this.running = false;
  }
  update(rpm, throttle, speed, drift) {
    if (!this.running) return;
    const t = this.ctx.currentTime;
    const f = 28 + (rpm / 60) * 1.6;
    this.o1.frequency.setTargetAtTime(f, t, 0.03);
    this.o2.frequency.setTargetAtTime(f * 0.5, t, 0.03);
    this.o3.frequency.setTargetAtTime(f * 0.25, t, 0.03);
    this.filter.frequency.setTargetAtTime(250 + throttle * 1500 + rpm * 0.18, t, 0.05);
    this.eGain.gain.setTargetAtTime((0.05 + throttle * 0.07) * this.engineVol, t, 0.05);
    this.sGain.gain.setTargetAtTime(Math.min(0.22, drift * 0.3) * (speed > 6 ? 1 : 0), t, 0.05);
    this.wGain.gain.setTargetAtTime(Math.min(0.12, (speed / 90) ** 2 * 0.12), t, 0.1);
  }
  impact(strength = 1) {
    if (!this.ctx) return;
    const c = this.ctx;
    const src = c.createBufferSource(); src.buffer = this.noise;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 500;
    const g = c.createGain();
    g.gain.setValueAtTime(Math.min(0.8, 0.2 + strength * 0.05), c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.35);
    src.connect(lp).connect(g).connect(this.master);
    src.start(); src.stop(c.currentTime + 0.4);
  }
  beep(freq = 660, dur = 0.15, vol = 0.25) {
    if (!this.ctx) return;
    const c = this.ctx;
    const o = c.createOscillator(); o.type = 'square'; o.frequency.value = freq;
    const g = c.createGain();
    g.gain.setValueAtTime(vol, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
    o.connect(g).connect(this.master);
    o.start(); o.stop(c.currentTime + dur + 0.02);
  }
  click() { this.beep(1200, 0.04, 0.08); }
}
