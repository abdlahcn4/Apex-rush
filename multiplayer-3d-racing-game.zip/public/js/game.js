import * as THREE from 'three';
import { CAR_SPECS, CAR_ORDER, PAINTS, QUALITY, buildCar, carStats, upgradeCost, MAX_UPGRADE } from './cars.js';
import { save, settings, persist, persistSettings, carColor, carUpgrades, addCoins, setPB, resetProgress, nextCar, fmtTime, isTouch, isMobile } from './save.js';
import { initTextures, createSky, createMountains, createGround, CircuitTrack, EndlessHighway, LANES } from './track.js';
import { Vehicle, collideCars } from './vehicle.js';
import { AIRacer, TrafficSystem } from './ai.js';
import { HUD, esc } from './hud.js';
import { Input } from './input.js';
import { AudioEngine } from './audio.js';
import { Multiplayer } from './multiplayer.js';

const $ = (id) => document.getElementById(id);
const loadbar = (p) => { $('loadbar').style.width = `${p}%`; };
loadbar(15);
const trackData = await (await fetch('/js/trackdata.json')).json();
loadbar(30);

const NOINPUT = { throttle: 0, brake: 0, steer: 0, handbrake: false, analog: false };
const AI_NAMES = ['Nova', 'Blaze', 'Kaito', 'Rhea', 'Diesel', 'Vega', 'Orion', 'Luna', 'Rex', 'Sora'];
const MODE_NAMES = { freedrive: 'FREE DRIVE', timetrial: 'TIME TRIAL', airace: 'AI RACE', traffic: 'TRAFFIC RACING', checkpoint: 'CHECKPOINT CHALLENGE', mp: 'LAN RACE' };

/* ---------------- smoke particles ---------------- */
class Smoke {
  constructor(scene, n) {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const g = c.getContext('2d');
    const gr = g.createRadialGradient(32, 32, 2, 32, 32, 32);
    gr.addColorStop(0, 'rgba(235,230,225,1)');
    gr.addColorStop(1, 'rgba(235,230,225,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    const tex = new THREE.CanvasTexture(c);
    this.parts = [];
    this.i = 0;
    for (let k = 0; k < n; k++) {
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0 }));
      s.visible = false;
      s.userData.life = 0;
      scene.add(s);
      this.parts.push(s);
    }
    this.scene = scene;
  }
  emit(x, z) {
    if (!this.parts.length) return;
    const s = this.parts[this.i++ % this.parts.length];
    s.position.set(x + (Math.random() - 0.5) * 0.4, 0.35, z + (Math.random() - 0.5) * 0.4);
    s.userData.life = 1;
    s.scale.setScalar(0.8);
    s.visible = true;
  }
  update(dt) {
    for (const s of this.parts) {
      if (s.userData.life <= 0) continue;
      s.userData.life -= dt * 0.9;
      s.scale.addScalar(dt * 3.2);
      s.position.y += dt * 0.6;
      s.material.opacity = Math.max(0, s.userData.life * 0.32);
      if (s.userData.life <= 0) s.visible = false;
    }
  }
  dispose() { for (const s of this.parts) this.scene.remove(s); this.parts = []; }
}

/* ======================================================================= */
class Game {
  constructor() {
    this.hud = new HUD();
    this.input = new Input();
    this.audio = new AudioEngine();
    this.audio.setVolume(settings.volume, settings.engineVol);
    this.mode = null;
    this.state = 'menu';
    this.paused = false;
    this.worldActive = false;
    this.camMode = settings.camMode;
    this.shake = 0;
    this.camYaw = 0;
    this.time = 0;
    this.screen = 'loading';
    this.gCar = save.selected;
    this.lbMode = 'timetrial';

    // renderer
    const q = QUALITY[settings.quality] ?? 2;
    this.renderer = new THREE.WebGLRenderer({ canvas: $('game'), antialias: q >= 1, powerPreference: 'high-performance' });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    initTextures(this.renderer);

    this.camera = new THREE.PerspectiveCamera(settings.fov, innerWidth / innerHeight, 0.1, 6000);
    this.buildWorldScene();
    this.buildShowroom();
    this.applyQuality();
    addEventListener('resize', () => this.resize());
    this.resize();

    this.input.handlers.camera = () => this.cycleCamera();
    this.input.handlers.pause = () => this.togglePause();
    this.input.handlers.reset = () => this.resetCar();
    this.mp = new Multiplayer(this);
    this.bindUI();
  }

  /* ---------------- scenes ---------------- */
  buildWorldScene() {
    const s = (this.scene = new THREE.Scene());
    this.sky = createSky();
    s.add(this.sky.mesh);
    this.horizon = new THREE.Color('#f0a878');
    s.fog = new THREE.Fog(this.horizon, 160, 1300);
    this.hemi = new THREE.HemisphereLight('#ffd8b8', '#4b5a2c', 1.0);
    s.add(this.hemi);
    this.sun = new THREE.DirectionalLight('#ffc48a', 2.6);
    this.sun.shadow.camera.left = -55; this.sun.shadow.camera.right = 55;
    this.sun.shadow.camera.top = 55; this.sun.shadow.camera.bottom = -55;
    this.sun.shadow.camera.near = 1; this.sun.shadow.camera.far = 600;
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.04;
    s.add(this.sun, this.sun.target);
    this.mountains = createMountains(QUALITY[settings.quality]);
    s.add(this.mountains);
    this.ground = createGround();
    s.add(this.ground);
    this.sunDir = new THREE.Vector3();
    this.updateSun(0);
    // environment map from the sky for reflections
    const pm = new THREE.PMREMGenerator(this.renderer);
    const envScene = new THREE.Scene();
    const envSky = createSky();
    envSky.uniforms.sunDir.value.copy(this.sunDir);
    envScene.add(envSky.mesh);
    const gnd = new THREE.Mesh(new THREE.CircleGeometry(3000, 16), new THREE.MeshBasicMaterial({ color: '#4a4636' }));
    gnd.rotation.x = -Math.PI / 2; gnd.position.y = -5;
    envScene.add(gnd);
    this.env = pm.fromScene(envScene, 0.03).texture;
    s.environment = this.env;
  }
  buildShowroom() {
    const s = (this.show = new THREE.Scene());
    const sky = createSky();
    sky.uniforms.sunDir.value.set(-0.5, 0.12, -0.85).normalize();
    s.add(sky.mesh);
    this.showSky = sky;
    s.environment = this.env;
    s.add(new THREE.HemisphereLight('#ffd8b8', '#3a3020', 1.1));
    const key = new THREE.DirectionalLight('#ffcf9a', 2.4);
    key.position.set(-6, 8, -10);
    s.add(key);
    const rim = new THREE.DirectionalLight('#7fb6ff', 1.2);
    rim.position.set(8, 5, 8);
    s.add(rim);
    const floor = new THREE.Mesh(new THREE.CircleGeometry(60, 48), new THREE.MeshStandardMaterial({ color: '#2a2622', roughness: 0.6, metalness: 0.2 }));
    floor.rotation.x = -Math.PI / 2;
    s.add(floor);
    const plat = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 3.8, 0.16, 64), new THREE.MeshStandardMaterial({ color: '#15171c', metalness: 0.8, roughness: 0.18 }));
    plat.position.y = 0.08;
    s.add(plat);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(3.7, 0.04, 8, 96), new THREE.MeshBasicMaterial({ color: '#ff7a18' }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.17;
    s.add(ring);
    this.turntable = new THREE.Group();
    this.turntable.position.y = 0.16;
    s.add(this.turntable);
    this.showCam = new THREE.PerspectiveCamera(40, innerWidth / innerHeight, 0.1, 6000);
    this.showAngle = 0.6;
    this.setShowroomCar(save.selected, carColor(save.selected));
  }
  setShowroomCar(id, color) {
    if (this.showCar) this.turntable.remove(this.showCar.root);
    this.showCar = buildCar(id, color, Math.max(2, QUALITY[settings.quality]));
    this.turntable.add(this.showCar.root);
    this.showCarId = id;
  }
  updateSun(t) {
    const el = 0.15 + 0.07 * Math.sin(t / 80);
    const az = 0.32 + 0.05 * Math.sin(t / 130);
    this.sunDir.set(Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el)).normalize();
    this.sky.uniforms.sunDir.value.copy(this.sunDir);
    this.sky.uniforms.time.value = t;
    const warm = 1 - (el - 0.08) / 0.14;
    this.sun.color.setHSL(0.075, 0.95, 0.62 + (1 - warm) * 0.12);
    this.sun.intensity = 2.2 + (1 - warm) * 0.8;
    this.sky.uniforms.horizon.value.setHSL(0.07, 1, 0.66 + (1 - warm) * 0.06);
    this.scene.fog.color.copy(this.sky.uniforms.horizon.value).lerp(new THREE.Color('#d9a58a'), 0.35);
  }
  applyQuality() {
    const q = QUALITY[settings.quality] ?? 2;
    this.q = q;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, [0.8, 1.1, 1.5, 2][q]));
    const sh = q >= 1;
    if (this.renderer.shadowMap.enabled !== sh) {
      this.renderer.shadowMap.enabled = sh;
      this.scene.traverse((o) => { if (o.material) [].concat(o.material).forEach((m) => (m.needsUpdate = true)); });
    }
    this.sun.castShadow = sh;
    const size = [512, 1024, 2048, 2048][q];
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size);
      this.sun.shadow.map?.dispose();
      this.sun.shadow.map = null;
    }
    this.scene.fog.far = [650, 950, 1350, 1800][q];
    this.scene.fog.near = [90, 140, 180, 220][q];
    this.ground.receiveShadow = sh;
    this.resize();
  }
  resize() {
    const w = innerWidth, h = innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.showCam.aspect = w / h;
    this.showCam.updateProjectionMatrix();
    this.checkOrientation();
  }
  checkOrientation() {
    const playing = this.worldActive;
    $('rotate').hidden = !(playing && isTouch && innerHeight > innerWidth);
  }

  /* ---------------- screens ---------------- */
  showScreen(name) {
    this.screen = name;
    for (const el of document.querySelectorAll('.screen')) el.classList.toggle('show', el.id === `scr-${name}`);
    $('hud').hidden = true;
    $('touch').hidden = true;
    $('pause').hidden = true;
    if (name !== 'results') $('results').hidden = true;
    for (const c of document.querySelectorAll('.coins-val')) c.textContent = save.coins.toLocaleString();
    $('menu-player').textContent = settings.name;
    $('menu-car').textContent = CAR_SPECS[save.selected].name;
    if (name === 'sp') this.renderSP();
    if (name === 'garage') { this.gCar = save.selected; this.renderGarage(); }
    if (name === 'settings') this.renderSettings();
    if (name === 'mp') this.mp.onShowMp();
    if (name === 'lobby') {
      this.mp.renderCarPicker();
      this.setShowroomCar(this.mp.myCar, this.mp.myColor);
    } else if (name !== 'garage' && (this.showCarId !== save.selected)) this.setShowroomCar(save.selected, carColor(save.selected));
    this.checkOrientation();
  }
  toMenu(screen = 'menu') {
    this.teardownWorld();
    this.showScreen(screen);
  }

  /* ---------------- world lifecycle ---------------- */
  teardownWorld() {
    if (!this.worldActive && !this.track) return;
    this.worldActive = false;
    this.audio.stopEngine();
    this.hud.show(false);
    this.hud.net('');
    if (this.track) this.track.dispose(this.scene);
    this.track = null;
    if (this.player) this.scene.remove(this.player.root);
    this.player = null;
    for (const a of this.ais || []) this.scene.remove(a.root);
    this.ais = [];
    this.traffic?.dispose();
    this.traffic = null;
    this.smoke?.dispose();
    this.smoke = null;
    if (this.cpGate) this.scene.remove(this.cpGate);
    this.cpGate = null;
    this.mp.clearRemotes();
    this.paused = false;
    $('pause').hidden = true;
    $('results').hidden = true;
    $('touch').hidden = true;
    this.checkOrientation();
  }
  setupWorld(kind, carId, color, upgrades) {
    this.teardownWorld();
    this.applyQuality();
    const q = this.q;
    this.track = kind === 'circuit' ? new CircuitTrack(trackData) : new EndlessHighway();
    this.track.build(this.scene, q);
    this.hud.setTrack(this.track);
    this.player = new Vehicle(carId, color, upgrades, q);
    this.scene.add(this.player.root);
    this.smoke = q >= 1 ? new Smoke(this.scene, [0, 24, 40, 60][q]) : null;
    this.ais = [];
    this.worldActive = true;
    for (const el of document.querySelectorAll('.screen')) el.classList.remove('show');
    this.hud.show(true);
    this.hud.setBoard([]);
    this.hud.big('');
    this.hud.countdown('');
    const touchOn = settings.touchControls === 'on' || (settings.touchControls === 'auto' && isTouch);
    $('touch').hidden = !touchOn;
    document.body.classList.toggle('touch-hud', touchOn);
    $('t-buttons').hidden = settings.touchSteer === 'wheel';
    $('t-wheel').hidden = settings.touchSteer !== 'wheel';
    this.input.enabled = true;
    this.audio.unlock();
    this.audio.startEngine();
    this.time = 0;
    this.shake = 0;
    this.camMode = this.camMode ?? settings.camMode;
    this.maxSpeed = 0;
    this.distance = 0;
    this.checkOrientation();
  }
  gridPos(slot) {
    const row = Math.floor(slot / 2), col = slot % 2;
    const p = this.track.pointAt(-12 - row * 9, col ? -3.4 : 3.4);
    return { x: p.x, z: p.z, h: Math.atan2(p.tx, p.tz) };
  }
  placePlayer(x, z, h) {
    this.player.reset(x, z, h);
    this.camYaw = h;
    const f = [Math.sin(h), Math.cos(h)];
    this.camera.position.set(x - f[0] * 7, 3, z - f[1] * 7);
  }

  /* ---------------- single player ---------------- */
  startSP(mode) {
    this.mode = mode;
    this.lastMode = mode;
    const id = save.selected;
    const circuit = mode === 'timetrial' || mode === 'airace';
    this.setupWorld(circuit ? 'circuit' : 'endless', id, carColor(id), carUpgrades(id));
    this.laps = 3;
    this.lap = 1;
    this.nextCp = 1;
    this.raceTime = 0;
    this.lapStart = 0;
    this.lapTimes = [];
    this.finished = false;
    this.awarded = false;
    if (circuit) {
      const slot = mode === 'airace' ? 5 : 0;
      const g = this.gridPos(slot);
      this.placePlayer(g.x, g.z, g.h);
      if (mode === 'airace') {
        const pool = CAR_ORDER.filter((c) => c !== id);
        for (let i = 0; i < 5; i++) {
          const carId = pool[i % pool.length];
          const color = PAINTS[(i * 3 + 1) % PAINTS.length];
          const row = Math.floor(i / 2), col = i % 2;
          const ai = new AIRacer(this.track, carId, color, this.q, 0.83 + i * 0.025 + Math.random() * 0.02, AI_NAMES[(i + Math.floor(Math.random() * 5)) % AI_NAMES.length] + ' ' + String.fromCharCode(65 + i), -12 - row * 9, col ? -3.4 : 3.4);
          this.scene.add(ai.root);
          this.ais.push(ai);
        }
      }
      this.state = 'countdown';
      this.countdown = 4;
    } else {
      const p = this.track.pointAt(0, 2.25);
      this.placePlayer(p.x, p.z, Math.atan2(p.tx, p.tz));
      const counts = [10, 14, 18, 22][this.q];
      const mult = mode === 'traffic' ? 1.5 : mode === 'checkpoint' ? 1.1 : 0.8;
      this.traffic = new TrafficSystem(this.scene, this.track, this.q, Math.round(counts * mult));
      this.traffic.reset(0);
      this.score = 0; this.combo = 0; this.comboT = 0; this.nearMisses = 0; this.crashes = 0;
      this.timeLeft = mode === 'traffic' ? 120 : 35;
      this.cps = 0;
      this.cpNext = 1500;
      if (mode === 'checkpoint') this.placeGate();
      this.state = mode === 'freedrive' ? 'racing' : 'countdown';
      this.countdown = 4;
    }
    if (isMobile && !document.fullscreenElement) this.fullscreen();
  }
  placeGate() {
    if (this.cpGate) this.scene.remove(this.cpGate);
    this.cpGate = this.track.makeCheckpointGate(this.cpNext, this.q);
    this.scene.add(this.cpGate);
  }
  restart() {
    if (this.mode === 'mp') return;
    this.startSP(this.lastMode);
  }
  playerProgress() {
    const L = this.track.length;
    let s = this.player.proj ? this.player.proj.s : 0;
    if (this.nextCp === 1 && s > L * 0.5) s -= L;
    if (this.nextCp === 0 && s < L * 0.5) s += L;
    return (this.lap - 1) * L + s;
  }

  /* ---------------- multiplayer hooks ---------------- */
  mpActive() { return this.mode === 'mp' && this.worldActive; }
  mpStartRace({ grid, laps, ms, state, resume }) {
    this.mode = 'mp';
    this.setupWorld('circuit', this.mp.myCar, this.mp.myColor, carUpgrades(this.mp.myCar));
    this.laps = laps;
    this.lap = 1; this.nextCp = 1;
    this.raceTime = 0; this.lapStart = 0; this.lapTimes = [];
    this.finished = false; this.awarded = false; this.mpPos = null;
    const slot = grid?.[this.mp.pid] ?? 0;
    const g = this.gridPos(Math.max(0, slot));
    this.placePlayer(g.x, g.z, g.h);
    this.mp.spawnRemotes(this.scene, this.q);
    this.state = 'countdown';
    this.countdown = (ms || 0) / 1000;
    if (resume) {
      this.lap = resume.lap; this.nextCp = resume.nextCp;
      if (resume.s && resume.s.length === 8) this.placePlayer(resume.s[0], resume.s[1], resume.s[2]);
      if (resume.state === 'racing') { this.state = resume.finished ? 'finished' : 'racing'; this.raceTime = resume.elapsed / 1000; this.countdown = 0; }
      this.finished = resume.finished;
    }
    $('results').hidden = true;
  }
  mpGo() {
    if (this.mode !== 'mp') return;
    if (this.state === 'countdown') { this.state = 'racing'; this.raceTime = 0; this.hud.countdown('GO!'); this.audio.beep(990, 0.4); setTimeout(() => this.hud.countdown(''), 900); }
  }
  mpCheckpoint({ lap, nextCp }) {
    if (lap !== this.lap) {
      const lt = this.raceTime - this.lapStart;
      this.lapTimes.push(lt);
      this.lapStart = this.raceTime;
      this.hud.toast(lap === this.laps ? 'FINAL LAP!' : `LAP ${lap}/${this.laps}  ·  ${fmtTime(lt * 1000)}`, 2000);
      this.audio.beep(880, 0.2);
    } else this.audio.beep(1320, 0.06, 0.12);
    this.lap = lap;
    this.nextCp = nextCp;
  }
  mpFinish({ time, pos }) {
    this.finished = true;
    this.state = 'finished';
    this.lapTimes.push(this.raceTime - this.lapStart);
    this.mpPos = pos;
    this.hud.big(`FINISHED  P${pos}`, pos === 1 ? '#ffd23f' : '#fff');
    this.hud.toast(fmtTime(time), 4000);
    this.audio.beep(1046, 0.5);
  }
  mpResults({ results }) {
    if (this.mode !== 'mp') return;
    this.state = 'finished';
    this.finished = true;
    const me = results.find((r) => r.pid === this.mp.pid);
    let coins = 0;
    if (!this.awarded && me) {
      coins = me.dnf ? 80 : [1000, 700, 500, 350, 250, 200, 150, 100][me.pos - 1] || 100;
      addCoins(coins);
      save.stats.races++;
      if (me.pos === 1 && !me.dnf && results.length > 1) save.stats.wins++;
      persist();
      this.awarded = true;
    }
    const rows = results.map((r) => `<tr class="${r.pid === this.mp.pid ? 'me' : ''}"><td>${r.pos}</td><td><span style="color:${r.color}">■</span> ${esc(r.name)}${r.connected ? '' : ' ⚠'}</td><td>${esc(CAR_SPECS[r.car]?.name || '')}</td><td>${r.dnf ? 'DNF' : fmtTime(r.time)}</td></tr>`).join('');
    this.showResults(me && !me.dnf ? `P${me.pos} — ${me.pos === 1 ? 'VICTORY!' : 'FINISHED'}` : 'RACE OVER',
      `<table class="r-table"><tr><th>POS</th><th>DRIVER</th><th>CAR</th><th>TIME</th></tr>${rows}</table>`, coins);
  }
  mpLobby() {
    if (this.mode === 'mp') this.teardownWorld();
    this.mode = null;
    if (this.mp.code) this.showScreen('lobby');
  }

  /* ---------------- main update ---------------- */
  update(dt) {
    const p = this.player;
    if (!p) return;
    const spPaused = this.paused && this.mode !== 'mp';
    if (spPaused) { this.updateCamera(0); return; }
    this.time += dt;
    this.updateSun(this.time + 30);
    const raw = this.input.read();
    const inp = this.paused || this.state === 'finished' ? NOINPUT : raw;

    // countdown
    if (this.state === 'countdown') {
      const before = Math.ceil(this.countdown);
      this.countdown -= dt;
      const now = Math.ceil(this.countdown);
      if (now !== before && now <= 3 && now > 0) this.audio.beep(660, 0.15);
      this.hud.countdown(this.countdown > 3 ? 'READY' : this.countdown > 0 ? String(now) : '');
      if (this.countdown <= 0) {
        this.state = 'racing';
        this.raceTime = 0;
        this.hud.countdown('GO!');
        this.audio.beep(990, 0.4);
        setTimeout(() => { if (this.hud) this.hud.countdown(''); }, 900);
      }
    }
    const frozen = this.state === 'countdown';
    if (this.state === 'racing') this.raceTime += dt;

    // physics substeps
    const steps = Math.min(4, Math.ceil(dt / (1 / 60)));
    const h = dt / steps;
    let hit = 0;
    for (let i = 0; i < steps; i++) {
      p.update(h, inp, this.track, frozen);
      if (p.impact > hit) hit = p.impact;
      for (const a of this.ais) {
        const imp = collideCars(p, a, 1, Infinity);
        if (imp > 0.5) { a.speed *= 0.93; a.targetLat = Math.max(-6.75, Math.min(6.75, a.lat + Math.sign(a.lat - (p.proj?.lat || 0)) * 2.5)); hit = Math.max(hit, imp); }
      }
      if (this.traffic) for (const c of this.traffic.cars) {
        const imp = collideCars(p, c, 1, Infinity);
        if (imp > 0.5) {
          c.hitT = 1.5; c.speed *= 0.85; hit = Math.max(hit, imp);
          if (imp > 3 && this.mode === 'traffic' && this.state === 'racing') { this.combo = 0; this.crashes++; this.timeLeft = Math.max(0, this.timeLeft - 2); this.hud.toast('CRASH  −2s', 1000); }
        }
      }
      if (this.mode === 'mp') for (const r of this.mp.remotes.values()) {
        if (!r.model.root.visible) continue;
        const imp = collideCars(p, r, 1, Infinity);
        if (imp > 0.5) hit = Math.max(hit, imp);
      }
    }
    if (hit > 3) { this.audio.impact(hit); this.shake = Math.min(1, hit / 15); }
    p.sync(dt);
    const kmh = Math.abs(p.vF) * 3.6;
    this.maxSpeed = Math.max(this.maxSpeed, kmh);
    if (this.state === 'racing' || this.mode === 'freedrive') this.distance += p.speed * dt;

    // smoke
    if (this.smoke) {
      if (p.drift > 0.35 && p.speed > 8 && Math.random() < 0.9) {
        const f = p.forward;
        for (const sx of [-0.9, 0.9]) this.smoke.emit(p.x - f[0] * 1.4 + f[1] * sx * -1, p.z - f[1] * 1.4 + f[0] * sx);
      }
      this.smoke.update(dt);
    }

    // mode logic
    if (this.mode === 'timetrial' || this.mode === 'airace') this.updateCircuitSP(dt);
    else if (this.mode === 'mp') this.updateMP(dt);
    else this.updateEndless(dt);

    // audio + effects
    this.audio.update(p.rpm, inp.throttle, p.speed, p.drift);
    this.hud.speed(kmh, p.gear, (p.rpm - 800) / 7000, p.stats.top * 3.6);
    this.hud.speedLines(kmh, settings.motion);
    this.updateCamera(dt);
  }

  updateCircuitSP(dt) {
    const p = this.player, tr = this.track;
    if (this.state === 'racing' && !this.finished) {
      const cp = tr.checkpoints[this.nextCp];
      if ((p.x - cp.x) ** 2 + (p.z - cp.z) ** 2 < tr.cpRadius ** 2) {
        if (this.nextCp === 0) {
          const lt = this.raceTime - this.lapStart;
          this.lapTimes.push(lt);
          this.lapStart = this.raceTime;
          this.lap++;
          if (this.lap > this.laps) { this.lap = this.laps; this.finishSP(); }
          else { this.hud.toast(this.lap === this.laps ? `FINAL LAP · ${fmtTime(lt * 1000)}` : `LAP ${this.lap}/${this.laps} · ${fmtTime(lt * 1000)}`, 2000); this.audio.beep(880, 0.2); }
        } else this.audio.beep(1320, 0.05, 0.1);
        this.nextCp = (this.nextCp + 1) % tr.checkpoints.length;
      }
    }
    const prog = this.finished ? this.laps * tr.length + 1e6 - this.raceTime : this.playerProgress();
    const others = [...this.ais, { s: prog, lat: p.proj?.lat ?? 0, speed: p.speed }];
    for (const a of this.ais) {
      const was = a.finished;
      a.update(dt, others, prog, this.state === 'countdown', this.laps);
      if (!was && a.finished) a.finishTime = this.raceTime;
    }
    // standings
    const entries = [{ me: true, name: settings.name, color: carColor(save.selected), prog, fin: this.finished, ft: this.finishTime, lap: this.lap },
      ...this.ais.map((a) => ({ me: false, name: a.name, color: a.color, prog: a.s, fin: a.finished, ft: a.finishTime, lap: Math.min(this.laps, Math.max(1, Math.floor(a.s / tr.length) + 1)) }))];
    entries.sort((a, b) => (a.fin !== b.fin ? (a.fin ? -1 : 1) : a.fin ? a.ft - b.ft : b.prog - a.prog));
    const myPos = entries.findIndex((e) => e.me) + 1;
    this.myPos = myPos;
    const curLap = this.raceTime - this.lapStart;
    if (this.mode === 'airace') {
      const leader = entries[0];
      this.hud.setBoard(entries.map((e, i) => ({ pos: i + 1, name: e.name, color: e.color, me: e.me, info: e.fin ? '🏁' : i === 0 ? 'LEADER' : `+${Math.max(0, (leader.prog - e.prog) / Math.max(20, this.player.stats.top * 0.75)).toFixed(1)}s` })), 'SUNSET RING');
      this.hud.top({ pos: `${myPos}/${entries.length}`, lap: `${this.lap}/${this.laps}`, time: this.raceTime * 1000, extraLabel: 'LAP TIME', extra: fmtTime(curLap * 1000) });
    } else {
      const pb = save.pbs.tt_lap;
      this.hud.setBoard([
        ...this.lapTimes.map((t, i) => ({ pos: i + 1, name: `Lap ${i + 1}`, color: '#1fa2ff', info: fmtTime(t * 1000), me: pb != null && Math.abs(t * 1000 - Math.min(...this.lapTimes.map((x) => x * 1000))) < 1 })),
        { pos: '★', name: 'Best lap PB', color: '#ffd23f', info: fmtTime(pb) },
      ], 'TIME TRIAL');
      this.hud.top({ pos: null, lap: `${this.lap}/${this.laps}`, time: this.raceTime * 1000, extraLabel: 'LAP TIME', extra: fmtTime(curLap * 1000) });
    }
    this.hud.minimap(tr, p, this.ais.map((a) => ({ x: a.x, z: a.z, color: a.color })), [{ x: tr.checkpoints[this.nextCp].x, z: tr.checkpoints[this.nextCp].z, color: '#2ee59d' }]);
  }

  finishSP() {
    this.finished = true;
    this.finishTime = this.raceTime;
    this.state = 'finished';
    const total = this.raceTime * 1000;
    const best = Math.min(...this.lapTimes) * 1000;
    if (this.mode === 'timetrial') {
      const pbLap = setPB('tt_lap', best, true);
      const pbTot = setPB('tt_total', total, true);
      const coins = 150 + (pbLap ? 100 : 0) + (pbTot ? 150 : 0);
      addCoins(coins);
      save.stats.races++; persist();
      this.postScore('timetrial', total);
      this.postScore('bestlap', best);
      this.showResults('TIME TRIAL COMPLETE', `<div class="r-stats">
        <div><small>TOTAL</small><b>${fmtTime(total)}</b>${pbTot ? '<div class="pb">NEW RECORD!</div>' : ''}</div>
        <div><small>BEST LAP</small><b>${fmtTime(best)}</b>${pbLap ? '<div class="pb">NEW RECORD!</div>' : ''}</div>
        <div><small>TOP SPEED</small><b>${Math.round(this.maxSpeed)} km/h</b></div></div>
        <table class="r-table"><tr><th>LAP</th><th>TIME</th></tr>${this.lapTimes.map((t, i) => `<tr><td>${i + 1}</td><td>${fmtTime(t * 1000)}</td></tr>`).join('')}</table>`, coins);
    } else {
      const pos = 1 + this.ais.filter((a) => a.finished).length;
      const coins = [1200, 800, 550, 350, 250, 150][pos - 1];
      addCoins(coins);
      save.stats.races++;
      if (pos === 1) save.stats.wins++;
      persist();
      setPB('ai_best', pos, true);
      this.audio.beep(1046, 0.5);
      this.showResults(pos === 1 ? 'VICTORY!' : `FINISHED P${pos}`, `<div class="r-stats">
        <div><small>POSITION</small><b>P${pos} / 6</b></div><div><small>TIME</small><b>${fmtTime(total)}</b></div>
        <div><small>BEST LAP</small><b>${fmtTime(best)}</b></div><div><small>TOP SPEED</small><b>${Math.round(this.maxSpeed)} km/h</b></div></div>`, coins);
    }
  }

  updateEndless(dt) {
    const p = this.player, tr = this.track;
    tr.update(p.z);
    this.traffic.update(dt, p.z, p.speed);
    const lat = p.proj?.lat ?? 0;
    if (this.mode === 'traffic' && this.state === 'racing') {
      this.timeLeft -= dt;
      this.comboT -= dt;
      if (this.comboT <= 0) this.combo = 0;
      const mult = 1 + this.combo * 0.5;
      if (p.vF > 0) this.score += p.vF * dt * (p.speed > 28 ? 1 + (p.speed - 28) / 25 : 0.4) * mult;
      for (const c of this.traffic.cars) {
        const rel = c.s - p.z;
        if (c.rel > 0 && rel <= 0 && Math.abs(c.lat - lat) < 3.7 && p.speed > 25 && c.hitT === 0) {
          this.combo = Math.min(10, this.combo + 1);
          this.comboT = 4;
          this.nearMisses++;
          const bonus = 150 * this.combo;
          this.score += bonus;
          this.hud.toast(`NEAR MISS! +${bonus}  x${this.combo}`, 900);
          this.audio.beep(1500, 0.06, 0.1);
        }
        c.rel = rel;
      }
      if (this.timeLeft <= 0) { this.timeLeft = 0; this.finishEndless(); }
    } else if (this.traffic) for (const c of this.traffic.cars) c.rel = c.s - p.z;
    if (this.mode === 'checkpoint' && this.state === 'racing') {
      this.timeLeft -= dt;
      if (p.z >= this.cpNext) {
        this.cps++;
        const bonus = Math.max(14, 26 - this.cps * 0.8);
        this.timeLeft += bonus;
        this.hud.toast(`CHECKPOINT ${this.cps}  +${bonus.toFixed(1)}s`, 1500);
        this.audio.beep(1200, 0.25);
        this.cpNext += 1500 + this.cps * 100;
        this.placeGate();
      }
      if (this.timeLeft <= 0) { this.timeLeft = 0; this.finishEndless(); }
    }
    const tl = `${Math.max(0, this.timeLeft || 0).toFixed(1)}s`;
    if (this.mode === 'freedrive') {
      this.hud.top({ pos: null, lap: null, time: this.time * 1000, extraLabel: 'DISTANCE', extra: `${(this.distance / 1000).toFixed(2)} km` });
      this.hud.setBoard([
        { pos: '⚡', name: 'Top speed', color: '#ff7a18', info: `${Math.round(this.maxSpeed)} km/h` },
        { pos: '🛣', name: 'Distance', color: '#1fa2ff', info: `${(this.distance / 1000).toFixed(2)} km` },
        { pos: '★', name: 'Longest drive', color: '#ffd23f', info: `${((save.pbs.fd_dist || 0) / 1000).toFixed(2)} km` },
      ], 'FREE DRIVE');
    } else if (this.mode === 'traffic') {
      this.hud.top({ pos: null, lap: null, time: tl, timeLabel: 'TIME LEFT', extraLabel: 'SCORE', extra: Math.round(this.score).toLocaleString() });
      this.hud.setBoard([
        { pos: 'x', name: 'Combo', color: '#ff7a18', info: this.combo ? `x${this.combo}` : '-' },
        { pos: '⚡', name: 'Near misses', color: '#2ee59d', info: this.nearMisses },
        { pos: '💥', name: 'Crashes', color: '#ff3b5c', info: this.crashes },
        { pos: '★', name: 'Best score', color: '#ffd23f', info: (save.pbs.traffic || 0).toLocaleString() },
      ], 'TRAFFIC RACING');
    } else {
      this.hud.top({ pos: null, lap: null, time: tl, timeLabel: 'TIME LEFT', extraLabel: 'NEXT CP', extra: `${Math.max(0, Math.round(this.cpNext - p.z))} m` });
      this.hud.setBoard([
        { pos: '🚩', name: 'Checkpoints', color: '#1fa2ff', info: this.cps },
        { pos: '🛣', name: 'Distance', color: '#2ee59d', info: `${(this.distance / 1000).toFixed(2)} km` },
        { pos: '★', name: 'Best distance', color: '#ffd23f', info: `${((save.pbs.cp_dist || 0) / 1000).toFixed(2)} km` },
      ], 'CHECKPOINTS');
    }
    const extras = this.mode === 'checkpoint' ? [{ ...tr.pointAt(this.cpNext), color: '#2ee59d' }] : [];
    this.hud.minimap(tr, p, this.traffic.cars.map((c) => ({ x: c.x, z: c.z, color: '#ffd23f' })), extras);
  }

  finishEndless() {
    if (this.finished) return;
    this.finished = true;
    this.state = 'finished';
    const dist = Math.round(this.distance);
    if (this.mode === 'traffic') {
      const sc = Math.round(this.score);
      const pb = setPB('traffic', sc, false);
      const coins = Math.round(sc / 40);
      addCoins(coins);
      this.postScore('traffic', sc);
      this.showResults('TIME UP!', `<div class="r-stats"><div><small>SCORE</small><b>${sc.toLocaleString()}</b>${pb ? '<div class="pb">NEW RECORD!</div>' : ''}</div>
        <div><small>NEAR MISSES</small><b>${this.nearMisses}</b></div><div><small>DISTANCE</small><b>${(dist / 1000).toFixed(2)} km</b></div><div><small>TOP SPEED</small><b>${Math.round(this.maxSpeed)} km/h</b></div></div>`, coins);
    } else if (this.mode === 'checkpoint') {
      const pb = setPB('cp_dist', dist, false);
      const coins = Math.round(dist / 20) + this.cps * 100;
      addCoins(coins);
      this.postScore('checkpoint', dist);
      this.showResults('OUT OF TIME', `<div class="r-stats"><div><small>DISTANCE</small><b>${(dist / 1000).toFixed(2)} km</b>${pb ? '<div class="pb">NEW RECORD!</div>' : ''}</div>
        <div><small>CHECKPOINTS</small><b>${this.cps}</b></div><div><small>TOP SPEED</small><b>${Math.round(this.maxSpeed)} km/h</b></div></div>`, coins);
    } else {
      const pb = setPB('fd_dist', dist, false);
      const coins = Math.round(dist / 250);
      addCoins(coins);
      this.showResults('DRIVE SUMMARY', `<div class="r-stats"><div><small>DISTANCE</small><b>${(dist / 1000).toFixed(2)} km</b>${pb ? '<div class="pb">NEW RECORD!</div>' : ''}</div>
        <div><small>TOP SPEED</small><b>${Math.round(this.maxSpeed)} km/h</b></div><div><small>TIME</small><b>${fmtTime(this.time * 1000)}</b></div></div>`, coins);
    }
    save.stats.distance += dist;
    persist();
  }

  updateMP(dt) {
    const p = this.player, mp = this.mp;
    mp.sendState(p, dt);
    mp.updateRemotes(dt);
    const st = mp.standings;
    const me = st.find((s) => s.pid === mp.pid);
    if (mp.raceElapsed != null && this.state !== 'countdown') {
      const serverT = (mp.raceElapsed + (performance.now() - mp.raceElapsedAt)) / 1000;
      if (Math.abs(serverT - this.raceTime) > 0.25) this.raceTime = serverT;
    }
    const pos = me ? me.pos : '-';
    this.hud.top({ pos: `${pos}/${Math.max(1, st.length || mp.remotes.size + 1)}`, lap: `${Math.min(this.lap, this.laps)}/${this.laps}`, time: this.finished && me?.time ? me.time : this.raceTime * 1000, extraLabel: 'LAP TIME', extra: fmtTime((this.raceTime - this.lapStart) * 1000) });
    this.hud.setBoard(st.map((s) => ({ pos: s.pos, name: s.name, color: s.color, me: s.pid === mp.pid, off: !s.connected, info: s.finished ? fmtTime(s.time) : `L${s.lap}` })), `ROOM ${mp.code || ''}`);
    const cars = [...mp.remotes.values()].filter((r) => r.model.root.visible).map((r) => ({ x: r.x, z: r.z, color: r.color }));
    const cp = this.track.checkpoints[this.nextCp] || this.track.checkpoints[0];
    this.hud.minimap(this.track, p, cars, [{ x: cp.x, z: cp.z, color: '#2ee59d' }]);
  }

  /* ---------------- camera ---------------- */
  cycleCamera() {
    if (!this.worldActive) return;
    this.camMode = (this.camMode + 1) % 3;
    this.hud.toast(['CHASE CAM', 'FAR CHASE CAM', 'FIRST PERSON'][this.camMode], 800);
  }
  updateCamera(dt) {
    const p = this.player;
    if (!p) return;
    const cam = this.camera;
    const kmh = Math.abs(p.vF) * 3.6;
    let dyaw = p.h - this.camYaw;
    dyaw = Math.atan2(Math.sin(dyaw), Math.cos(dyaw));
    this.camYaw += dyaw * Math.min(1, dt * (this.camMode === 2 ? 30 : 5));
    const b = p.model.spec.body;
    if (this.camMode === 2) {
      const f = [Math.sin(p.h), Math.cos(p.h)];
      const zf = b.cabF + 0.35;
      cam.position.set(p.x + f[0] * zf, b.beltY + 0.42, p.z + f[1] * zf);
      cam.lookAt(p.x + f[0] * 30, b.beltY + 0.1, p.z + f[1] * 30);
      p.model.body.visible = true;
    } else {
      const far = this.camMode === 1;
      const dist = (far ? 9.5 : 6.3) * settings.camDist + kmh * 0.004;
      const hgt = (far ? 3.4 : 2.25) * settings.camHeight;
      const fy = [Math.sin(this.camYaw), Math.cos(this.camYaw)];
      const tx = p.x - fy[0] * dist, tz = p.z - fy[1] * dist;
      const k = dt > 0 ? 1 - Math.exp(-dt * 14) : 1;
      cam.position.x += (tx - cam.position.x) * k;
      cam.position.z += (tz - cam.position.z) * k;
      cam.position.y += (hgt - cam.position.y) * k;
      cam.lookAt(p.x + fy[0] * 4, 1.1 * Math.max(0.8, settings.camHeight * 0.8), p.z + fy[1] * 4);
    }
    if (this.shake > 0 && settings.motion) {
      cam.position.x += (Math.random() - 0.5) * this.shake * 0.5;
      cam.position.y += (Math.random() - 0.5) * this.shake * 0.3;
      this.shake = Math.max(0, this.shake - dt * 2.5);
    }
    const fov = settings.fov + (settings.motion ? Math.min(14, Math.max(0, kmh - 60) * 0.055) : 0);
    if (Math.abs(cam.fov - fov) > 0.05) { cam.fov += (fov - cam.fov) * Math.min(1, dt * 4 || 1); cam.updateProjectionMatrix(); }
    // world followers
    this.sky.mesh.position.copy(cam.position);
    this.mountains.position.set(cam.position.x, 0, cam.position.z);
    this.ground.position.set(Math.round(cam.position.x / 10) * 10, 0, Math.round(cam.position.z / 10) * 10);
    this.sun.position.set(p.x + this.sunDir.x * 250, this.sunDir.y * 250, p.z + this.sunDir.z * 250);
    this.sun.target.position.set(p.x, 0, p.z);
    this.sun.target.updateMatrixWorld();
  }
  resetCar() {
    if (!this.worldActive || !this.player || this.state === 'countdown') return;
    const p = this.player;
    const pr = this.track.project(p.x, p.z, p.hint);
    const lane = LANES.reduce((a, l) => (Math.abs(l - pr.lat) < Math.abs(a - pr.lat) ? l : a), LANES[0]);
    const pt = this.track.pointAt(pr.s, lane);
    p.reset(pt.x, pt.z, Math.atan2(pt.tx, pt.tz));
    this.hud.toast('CAR RESET', 700);
  }

  /* ---------------- showroom ---------------- */
  updateShowroom(dt) {
    this.showAngle += dt * 0.25;
    const r = this.screen === 'garage' ? 7.6 : 8.4;
    const c = this.showCam;
    c.position.set(Math.sin(this.showAngle) * r, 2.2, Math.cos(this.showAngle) * r);
    c.lookAt(0, 0.7, 0);
    const w = innerWidth, h = innerHeight;
    if (this.screen === 'menu' && w > h) c.setViewOffset(w, h, -w * 0.2, 0, w, h);
    else if (this.screen === 'garage' && w > 700) c.setViewOffset(w, h, w * 0.04, -h * 0.05, w, h);
    else c.clearViewOffset();
    this.showSky.uniforms.time.value += dt;
    this.showSky.mesh.position.copy(c.position);
    if (this.showCar) for (const wh of this.showCar.wheels) if (wh.front) wh.pivot.rotation.y = Math.sin(this.showAngle * 0.7) * 0.3;
  }

  /* ---------------- results / pause ---------------- */
  showResults(title, body, coins) {
    $('r-title').textContent = title;
    $('r-body').innerHTML = body;
    $('r-coins').textContent = coins ? `+${coins.toLocaleString()} 🪙` : '';
    const mp = this.mode === 'mp';
    const retry = $('r-retry');
    if (mp) {
      const host = this.mp.isHost();
      retry.textContent = host ? 'BACK TO LOBBY' : 'WAITING FOR HOST…';
      retry.disabled = !host;
      $('r-menu').textContent = 'LEAVE ROOM';
    } else {
      retry.textContent = 'RACE AGAIN';
      retry.disabled = false;
      $('r-menu').textContent = 'MENU';
    }
    $('results').hidden = false;
    $('touch').hidden = true;
  }
  togglePause(force) {
    if (!this.worldActive || !$('results').hidden) return;
    this.paused = force ?? !this.paused;
    $('pause').hidden = !this.paused;
    $('p-restart').hidden = this.mode === 'mp';
    $('pause-note').textContent = this.mode === 'mp' ? 'Multiplayer keeps running while this menu is open.' : MODE_NAMES[this.mode] || '';
    $('p-quit').textContent = this.mode === 'mp' ? 'LEAVE RACE' : this.mode === 'freedrive' ? 'END DRIVE' : 'QUIT TO MENU';
    if (!this.paused) this.audio.unlock();
  }
  fullscreen() {
    const el = document.documentElement;
    const req = el.requestFullscreen || el.webkitRequestFullscreen;
    if (!req) return;
    Promise.resolve(req.call(el)).then(() => screen.orientation?.lock?.('landscape').catch(() => {})).catch(() => {});
  }
  postScore(mode, value) {
    fetch('/api/scores', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ mode, value: Math.round(value), name: settings.name, car: save.selected }) }).catch(() => {});
  }
  confirm(text, yes) {
    $('confirm-text').textContent = text;
    $('confirm').hidden = false;
    $('confirm-yes').onclick = () => { $('confirm').hidden = true; yes(); };
    $('confirm-no').onclick = () => { $('confirm').hidden = true; };
  }

  /* ---------------- menus ---------------- */
  renderSP() {
    const pbs = save.pbs;
    $('pb-freedrive').textContent = `Longest drive: ${((pbs.fd_dist || 0) / 1000).toFixed(2)} km`;
    $('pb-timetrial').textContent = `Best lap ${fmtTime(pbs.tt_lap)} · Total ${fmtTime(pbs.tt_total)}`;
    $('pb-airace').textContent = `Wins: ${save.stats.wins} · Best finish: ${pbs.ai_best ? 'P' + pbs.ai_best : '—'}`;
    $('pb-traffic').textContent = `Best score: ${(pbs.traffic || 0).toLocaleString()}`;
    $('pb-checkpoint').textContent = `Best distance: ${((pbs.cp_dist || 0) / 1000).toFixed(2)} km`;
    this.loadLeaderboard();
  }
  async loadLeaderboard() {
    const list = $('lb-list');
    list.innerHTML = '<li><span>Loading…</span></li>';
    try {
      const r = await (await fetch(`/api/scores?mode=${this.lbMode}`, { cache: 'no-store' })).json();
      const fmt = (v) => (this.lbMode === 'traffic' ? v.toLocaleString() + ' pts' : this.lbMode === 'checkpoint' ? (v / 1000).toFixed(2) + ' km' : fmtTime(v));
      list.innerHTML = r.rows.length ? r.rows.map((x) => `<li><span>${esc(x.name)} <small style="color:#9fb0cc">${esc(CAR_SPECS[x.car]?.name || '')}</small></span><span>${fmt(x.value)}</span></li>`).join('') : `<li><span>${r.offline ? 'Leaderboard database offline' : 'No records yet — be the first!'}</span></li>`;
    } catch {
      list.innerHTML = '<li><span>Leaderboard unavailable</span></li>';
    }
  }
  renderGarage() {
    const id = this.gCar, spec = CAR_SPECS[id];
    const owned = save.owned.includes(id);
    $('car-list').innerHTML = CAR_ORDER.map((c) => {
      const s = CAR_SPECS[c], o = save.owned.includes(c);
      return `<button class="car-card ${c === id ? 'on' : ''}" data-car="${c}"><b>${s.name}${c === save.selected ? ' ✔' : ''}</b><small>${s.tag}</small><small class="${o ? '' : 'lock'}">${o ? 'OWNED' : '🔒 ' + s.price.toLocaleString() + ' 🪙'}</small></button>`;
    }).join('');
    $('g-name').textContent = spec.name;
    $('g-tag').textContent = owned ? spec.tag : `LOCKED · ${spec.price.toLocaleString()} COINS`;
    const up = carUpgrades(id);
    const base = carStats(id), cur = carStats(id, up);
    const bar = (label, val, b, c, max, unit) => `<div class="st"><div><span>${label}</span><b>${val}${unit}</b></div><div class="bar2"><i class="up" style="width:${Math.min(100, (c / max) * 100)}%"></i><i style="width:${Math.min(100, (b / max) * 100)}%"></i></div></div>`;
    $('g-stats').innerHTML =
      bar('TOP SPEED', Math.round(cur.top * 3.6), base.top, cur.top, 110, ' km/h') +
      bar('0-100 KM/H', (27.8 / (cur.accel * 0.92)).toFixed(1), base.accel, cur.accel, 26, ' s') +
      bar('HANDLING', cur.handling.toFixed(2), base.handling, cur.handling, 1.5, '') +
      bar('BRAKING', Math.round(cur.brake), base.brake, cur.brake, 52, ' m/s²');
    const col = carColor(id);
    $('g-colors').innerHTML = PAINTS.map((c) => `<button data-c="${c}" class="${c.toLowerCase() === col.toLowerCase() ? 'on' : ''}" style="background:${c}"></button>`).join('');
    $('g-color-custom').value = col;
    $('g-upgrades').innerHTML = ['engine', 'brakes', 'handling'].map((k) => {
      const lvl = up[k];
      const cost = upgradeCost(id, lvl);
      const can = owned && lvl < MAX_UPGRADE && save.coins >= cost;
      return `<div class="up"><span>${k.toUpperCase()}</span><div class="pips">${Array.from({ length: MAX_UPGRADE }, (_, i) => `<i class="${i < lvl ? 'on' : ''}"></i>`).join('')}</div><button data-up="${k}" ${can ? '' : 'disabled'}>${lvl >= MAX_UPGRADE ? 'MAX' : cost.toLocaleString() + ' 🪙'}</button></div>`;
    }).join('');
    const act = $('g-action');
    if (owned) { act.textContent = save.selected === id ? 'SELECTED ✔' : 'SELECT CAR'; act.disabled = save.selected === id; }
    else { act.textContent = `BUY · ${spec.price.toLocaleString()} 🪙`; act.disabled = save.coins < spec.price; }
    for (const c of document.querySelectorAll('.coins-val')) c.textContent = save.coins.toLocaleString();
    if (this.showCarId !== id) this.setShowroomCar(id, col);
    else this.showCar.setColor(col);
  }
  renderSettings() {
    $('s-name').value = settings.name;
    const seg = (id, v) => { for (const b of $(id).children) b.classList.toggle('on', b.dataset.v === String(v)); };
    seg('s-quality', settings.quality);
    seg('s-cam', settings.camMode);
    seg('s-steer', settings.touchSteer);
    seg('s-touch', settings.touchControls);
    const rng = (id, v, f) => { $(id).value = v; $(id + '-v').textContent = f(v); };
    rng('s-camdist', settings.camDist, (v) => `${Math.round(v * 100)}%`);
    rng('s-camh', settings.camHeight, (v) => `${Math.round(v * 100)}%`);
    rng('s-fov', settings.fov, (v) => `${v}°`);
    rng('s-vol', settings.volume, (v) => `${Math.round(v * 100)}%`);
    rng('s-evol', settings.engineVol, (v) => `${Math.round(v * 100)}%`);
    $('s-motion').checked = settings.motion;
    $('s-fps').checked = settings.showFps;
  }

  bindUI() {
    document.addEventListener('pointerdown', () => this.audio.unlock(), { once: false, passive: true });
    document.addEventListener('click', (e) => {
      const go = e.target.closest('[data-go]');
      if (go) { this.audio.unlock(); this.audio.click(); this.showScreen(go.dataset.go); }
      if (e.target.closest('[data-fs]')) this.fullscreen();
    });
    for (const b of document.querySelectorAll('.mode')) b.addEventListener('click', () => { this.audio.unlock(); this.startSP(b.dataset.mode); });
    $('lb-tabs').addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      for (const x of $('lb-tabs').children) x.classList.toggle('on', x === b);
      this.lbMode = b.dataset.lb;
      this.loadLeaderboard();
    });
    // garage
    $('car-list').addEventListener('click', (e) => { const b = e.target.closest('[data-car]'); if (b) { this.gCar = b.dataset.car; this.renderGarage(); } });
    $('g-prev').addEventListener('click', () => { this.gCar = nextCar(this.gCar, -1); this.renderGarage(); });
    $('g-next').addEventListener('click', () => { this.gCar = nextCar(this.gCar, 1); this.renderGarage(); });
    $('g-colors').addEventListener('click', (e) => {
      const c = e.target.dataset?.c; if (!c) return;
      save.colors[this.gCar] = c; persist(); this.renderGarage();
    });
    $('g-color-custom').addEventListener('input', (e) => { save.colors[this.gCar] = e.target.value; persist(); this.showCar.setColor(e.target.value); });
    $('g-color-custom').addEventListener('change', () => this.renderGarage());
    $('g-upgrades').addEventListener('click', (e) => {
      const k = e.target.dataset?.up; if (!k) return;
      const up = carUpgrades(this.gCar);
      const cost = upgradeCost(this.gCar, up[k]);
      if (save.coins < cost || up[k] >= MAX_UPGRADE) return;
      save.coins -= cost; up[k]++; persist();
      this.audio.beep(880, 0.12);
      this.renderGarage();
    });
    $('g-action').addEventListener('click', () => {
      const id = this.gCar, spec = CAR_SPECS[id];
      if (!save.owned.includes(id)) {
        if (save.coins < spec.price) return;
        save.coins -= spec.price; save.owned.push(id);
        this.audio.beep(1046, 0.3);
      }
      save.selected = id; persist();
      this.renderGarage();
    });
    // settings
    const segBind = (id, key, conv = (v) => v, after) => $(id).addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      settings[key] = conv(b.dataset.v); persistSettings(); this.renderSettings(); after?.();
    });
    segBind('s-quality', 'quality', (v) => v, () => this.applyQuality());
    segBind('s-cam', 'camMode', Number, () => { this.camMode = settings.camMode; });
    segBind('s-steer', 'touchSteer');
    segBind('s-touch', 'touchControls');
    const rangeBind = (id, key, after) => $(id).addEventListener('input', (e) => { settings[key] = Number(e.target.value); persistSettings(); this.renderSettings(); after?.(); });
    rangeBind('s-camdist', 'camDist');
    rangeBind('s-camh', 'camHeight');
    rangeBind('s-fov', 'fov');
    rangeBind('s-vol', 'volume', () => this.audio.setVolume(settings.volume, settings.engineVol));
    rangeBind('s-evol', 'engineVol', () => this.audio.setVolume(settings.volume, settings.engineVol));
    $('s-motion').addEventListener('change', (e) => { settings.motion = e.target.checked; persistSettings(); });
    $('s-fps').addEventListener('change', (e) => { settings.showFps = e.target.checked; persistSettings(); if (!settings.showFps) this.hud.fps(0); });
    $('s-name').addEventListener('change', (e) => { settings.name = e.target.value.trim().slice(0, 16) || settings.name; persistSettings(); this.mp.sendConfig(); });
    $('s-reset').addEventListener('click', () => this.confirm('Reset all coins, cars, upgrades and records?', () => { resetProgress(); this.setShowroomCar(save.selected, carColor(save.selected)); this.hud.toast('Progress reset'); this.showScreen('settings'); }));
    $('settings-back').addEventListener('click', () => {
      if (this.settingsFromPause) { this.settingsFromPause = false; for (const el of document.querySelectorAll('.screen')) el.classList.remove('show'); this.screen = 'game'; $('hud').hidden = false; $('pause').hidden = false; this.applyTouchVisibility(); return; }
      this.showScreen('menu');
    });
    // pause
    $('btn-pause').addEventListener('click', () => this.togglePause());
    $('btn-cam').addEventListener('click', () => this.cycleCamera());
    $('p-resume').addEventListener('click', () => this.togglePause(false));
    $('p-restart').addEventListener('click', () => { this.paused = false; this.restart(); });
    $('p-settings').addEventListener('click', () => {
      this.settingsFromPause = true;
      $('pause').hidden = true;
      this.renderSettings();
      for (const el of document.querySelectorAll('.screen')) el.classList.toggle('show', el.id === 'scr-settings');
    });
    $('p-quit').addEventListener('click', () => {
      this.paused = false;
      $('pause').hidden = true;
      if (this.mode === 'mp') { this.mp.leave(); this.mode = null; this.toMenu('mp'); return; }
      if (this.mode === 'freedrive') { this.finishEndless(); return; }
      this.mode = null;
      this.toMenu('sp');
    });
    // results
    $('r-retry').addEventListener('click', () => {
      if (this.mode === 'mp') { this.mp.backToLobby(); return; }
      $('results').hidden = true;
      this.restart();
    });
    $('r-menu').addEventListener('click', () => {
      $('results').hidden = true;
      if (this.mode === 'mp') { this.mp.leave(); this.mode = null; this.toMenu('mp'); return; }
      this.mode = null;
      this.toMenu('sp');
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.worldActive && this.mode !== 'mp' && !this.paused && $('results').hidden) this.togglePause(true); });
  }
  applyTouchVisibility() {
    const touchOn = settings.touchControls === 'on' || (settings.touchControls === 'auto' && isTouch);
    $('touch').hidden = !touchOn || !$('results').hidden;
    $('t-buttons').hidden = settings.touchSteer === 'wheel';
    $('t-wheel').hidden = settings.touchSteer !== 'wheel';
  }
}

/* ======================================================================= */
const game = new Game();
window.__game = game;
loadbar(70);
await game.mp.loadLanInfo();
loadbar(100);
// pre-compile shaders of the showroom
game.renderer.compile(game.show, game.showCam);
$('loading').classList.remove('show');
game.showScreen('menu');
// Auto-offer rejoin if this tab was in a room (page reload)
if (game.mp.savedSession()) {
  game.mp.connect();
  const s = game.mp.savedSession();
  game.mp.join(s.code, s.key);
}

let last = performance.now();
let frames = 0, fpsT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, Math.max(0, (now - last) / 1000));
  last = now;
  if (game.worldActive) {
    game.update(dt);
    game.renderer.render(game.scene, game.camera);
  } else {
    game.updateShowroom(dt);
    game.renderer.render(game.show, game.showCam);
  }
  frames++;
  fpsT += dt;
  if (fpsT >= 1) {
    if (settings.showFps && game.worldActive) game.hud.fps(frames);
    frames = 0; fpsT = 0;
  }
}
requestAnimationFrame(frame);
