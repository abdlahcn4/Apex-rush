import { CAR_SPECS, CAR_ORDER } from './cars.js';

const SAVE_KEY = 'apexrush_save_v1';
const SET_KEY = 'apexrush_settings_v1';

export const isTouch = (window.matchMedia && matchMedia('(pointer: coarse)').matches) || 'ontouchstart' in window;
export const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || (isTouch && Math.min(screen.width, screen.height) < 820);

function parse(s) {
  try { return JSON.parse(s) || {}; } catch { return {}; }
}
function store(k, v) {
  try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ }
}
function read(k) {
  try { return parse(localStorage.getItem(k)); } catch { return {}; }
}

function defaultSave() {
  return { coins: 1000, owned: ['vortex'], selected: 'vortex', colors: {}, upgrades: {}, pbs: {}, stats: { races: 0, wins: 0, distance: 0 } };
}
export const save = Object.assign(defaultSave(), read(SAVE_KEY));
if (!save.owned.includes('vortex')) save.owned.push('vortex');
if (!CAR_SPECS[save.selected]) save.selected = 'vortex';

export function persist() { store(SAVE_KEY, save); }

const lowEnd = (navigator.deviceMemory && navigator.deviceMemory <= 4) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4);
export const settings = Object.assign(
  {
    name: 'Racer' + Math.floor(100 + Math.random() * 900),
    quality: isMobile ? (lowEnd ? 'low' : 'medium') : 'high',
    camMode: 0,
    camDist: 1,
    camHeight: 1,
    fov: 68,
    motion: true,
    showFps: false,
    volume: 0.7,
    engineVol: 0.8,
    touchSteer: 'buttons',
    touchControls: 'auto',
  },
  read(SET_KEY),
);
export function persistSettings() { store(SET_KEY, settings); }

export function carColor(id) { return save.colors[id] || CAR_SPECS[id].color; }
export function carUpgrades(id) {
  if (!save.upgrades[id]) save.upgrades[id] = { engine: 0, brakes: 0, handling: 0 };
  return save.upgrades[id];
}
export function addCoins(n) {
  save.coins = Math.max(0, Math.round(save.coins + n));
  persist();
}
/** Stores a personal best. Returns true when it's a new record. */
export function setPB(key, value, lowerBetter) {
  const cur = save.pbs[key];
  const better = cur == null || (lowerBetter ? value < cur : value > cur);
  if (better) {
    save.pbs[key] = value;
    persist();
  }
  return better;
}
export function resetProgress() {
  Object.assign(save, defaultSave());
  save.upgrades = {};
  save.colors = {};
  save.pbs = {};
  persist();
}
export function nextCar(id, dir) {
  const i = CAR_ORDER.indexOf(id);
  return CAR_ORDER[(i + dir + CAR_ORDER.length) % CAR_ORDER.length];
}
export function fmtTime(ms) {
  if (ms == null || !isFinite(ms)) return '--:--.-';
  const t = Math.max(0, ms) / 1000;
  const m = Math.floor(t / 60);
  const s = t - m * 60;
  return `${m}:${s < 10 ? '0' : ''}${s.toFixed(2)}`;
}
