import * as THREE from 'three';

export const ROAD_HALF = 11;
export const LANES = [-6.75, -2.25, 2.25, 6.75];
export const WALL = 11.5;

/* ---------------- helpers ---------------- */
export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function mergeGeos(list) {
  const pos = [], nor = [], uv = [];
  for (const g0 of list) {
    const g = g0.index ? g0.toNonIndexed() : g0;
    pos.push(...g.attributes.position.array);
    nor.push(...g.attributes.normal.array);
    if (g.attributes.uv) uv.push(...g.attributes.uv.array);
    else for (let i = 0; i < g.attributes.position.count; i++) uv.push(0, 0);
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  return out;
}

/* ---------------- textures ---------------- */
const tex = {};
function canvas(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}
function noise(g, w, h, amt) {
  const img = g.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * amt;
    d[i] += n; d[i + 1] += n; d[i + 2] += n;
  }
  g.putImageData(img, 0, 0);
}
export function initTextures(renderer) {
  const aniso = renderer.capabilities.getMaxAnisotropy();
  // Road: 22 m wide, 12 m long per tile
  {
    const [c, g] = canvas(512, 1024);
    g.fillStyle = '#4a4a50';
    g.fillRect(0, 0, 512, 1024);
    noise(g, 512, 1024, 30);
    const px = (m) => (m / 22) * 512;
    g.fillStyle = 'rgba(0,0,0,0.12)';
    for (const l of [-6.75, -2.25, 2.25, 6.75]) for (const o of [-0.9, 0.9]) g.fillRect(px(11 + l + o) - 14, 0, 28, 1024);
    g.fillStyle = 'rgba(90,90,96,0.5)';
    g.fillRect(0, 0, px(2), 1024);
    g.fillRect(px(20), 0, px(2), 1024);
    g.fillStyle = '#f2d24b';
    g.fillRect(px(2) - 5, 0, 10, 1024);
    g.fillStyle = '#eeeeee';
    g.fillRect(px(20) - 5, 0, 10, 1024);
    for (const k of [1, 2, 3]) g.fillRect(px(2 + 4.5 * k) - 4, 0, 8, 1024 * (4.5 / 12));
    const t = new THREE.CanvasTexture(c);
    t.wrapS = THREE.ClampToEdgeWrapping;
    t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = aniso;
    t.colorSpace = THREE.SRGBColorSpace;
    tex.road = t;
  }
  {
    const [c, g] = canvas(256, 256);
    g.fillStyle = '#7d8a3c';
    g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 2600; i++) {
      const v = Math.random();
      g.fillStyle = v < 0.33 ? '#9a9a4a' : v < 0.66 ? '#5f7330' : '#b0a055';
      g.fillRect(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 3, 2 + Math.random() * 3);
    }
    noise(g, 256, 256, 18);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = aniso;
    t.colorSpace = THREE.SRGBColorSpace;
    tex.grass = t;
  }
  {
    const [c, g] = canvas(128, 64);
    g.fillStyle = '#c9c4ba';
    g.fillRect(0, 0, 128, 64);
    noise(g, 128, 64, 22);
    g.fillStyle = '#b8242c';
    g.fillRect(0, 6, 128, 10);
    g.fillStyle = '#8f8a82';
    g.fillRect(0, 60, 128, 4);
    g.fillRect(126, 0, 2, 64);
    const t = new THREE.CanvasTexture(c);
    t.wrapS = THREE.RepeatWrapping;
    t.wrapT = THREE.ClampToEdgeWrapping;
    t.anisotropy = aniso;
    t.colorSpace = THREE.SRGBColorSpace;
    tex.wall = t;
  }
  {
    const [c, g] = canvas(64, 128);
    g.fillStyle = '#5a6070';
    g.fillRect(0, 0, 64, 128);
    for (let y = 4; y < 128; y += 10) for (let x = 4; x < 64; x += 10) {
      g.fillStyle = Math.random() < 0.3 ? '#ffcf7a' : Math.random() < 0.5 ? '#2a3448' : '#8fb1d6';
      g.fillRect(x, y, 6, 6);
    }
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.colorSpace = THREE.SRGBColorSpace;
    tex.windows = t;
  }
  {
    const [c, g] = canvas(256, 64);
    for (let y = 0; y < 4; y++) for (let x = 0; x < 16; x++) {
      g.fillStyle = (x + y) % 2 ? '#111' : '#fff';
      g.fillRect(x * 16, y * 16, 16, 16);
    }
    tex.checker = new THREE.CanvasTexture(c);
    tex.checker.colorSpace = THREE.SRGBColorSpace;
  }
  {
    const [c, g] = canvas(1024, 128);
    const gr = g.createLinearGradient(0, 0, 1024, 0);
    gr.addColorStop(0, '#ff7a18');
    gr.addColorStop(1, '#ff3b5c');
    g.fillStyle = gr;
    g.fillRect(0, 0, 1024, 128);
    g.fillStyle = '#fff';
    g.font = 'italic 900 84px Segoe UI, Arial';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('APEX RUSH  ·  SUNSET RING', 512, 66);
    tex.banner = new THREE.CanvasTexture(c);
    tex.banner.colorSpace = THREE.SRGBColorSpace;
  }
  {
    const [c, g] = canvas(1024, 128);
    g.fillStyle = '#1fa2ff';
    g.fillRect(0, 0, 1024, 128);
    g.fillStyle = '#fff';
    g.font = 'italic 900 90px Segoe UI, Arial';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('CHECKPOINT', 512, 66);
    tex.cpBanner = new THREE.CanvasTexture(c);
    tex.cpBanner.colorSpace = THREE.SRGBColorSpace;
  }
  return tex;
}

/* ---------------- materials ---------------- */
let M = null;
function materials() {
  if (M) return M;
  M = {
    road: new THREE.MeshStandardMaterial({ map: tex.road, roughness: 0.82, metalness: 0.05 }),
    wall: new THREE.MeshStandardMaterial({ map: tex.wall, roughness: 0.9, side: THREE.DoubleSide }),
    pole: new THREE.MeshStandardMaterial({ color: 0x8a8f99, metalness: 0.7, roughness: 0.4 }),
    lamp: new THREE.MeshStandardMaterial({ color: 0xfff1c9, emissive: 0xffd28a, emissiveIntensity: 1.5 }),
    trunk: new THREE.MeshLambertMaterial({ color: 0x5a3d26 }),
    leaf: new THREE.MeshLambertMaterial({ color: 0xffffff }),
    building: new THREE.MeshStandardMaterial({ map: tex.windows, roughness: 0.7, metalness: 0.2, emissive: 0x332211, emissiveIntensity: 0.25 }),
    checker: new THREE.MeshBasicMaterial({ map: tex.checker }),
    banner: new THREE.MeshBasicMaterial({ map: tex.banner, side: THREE.DoubleSide }),
    cpBanner: new THREE.MeshBasicMaterial({ map: tex.cpBanner, side: THREE.DoubleSide }),
    gantry: new THREE.MeshStandardMaterial({ color: 0x2b2f38, metalness: 0.6, roughness: 0.4 }),
  };
  return M;
}

/** Extrude a cross-section [[lateral, y], ...] along samples. */
function extrudeAlong(samples, cross, { closed = false, vScale = 12, uScale = null } = {}) {
  const n = samples.length, m = cross.length;
  const count = closed ? n + 1 : n;
  const pos = new Float32Array(count * m * 3);
  const uv = new Float32Array(count * m * 2);
  const u = [0];
  for (let j = 1; j < m; j++) u[j] = u[j - 1] + Math.hypot(cross[j][0] - cross[j - 1][0], cross[j][1] - cross[j - 1][1]);
  const ut = u[m - 1] || 1;
  const total = closed ? samples[n - 1].d + Math.hypot(samples[0].x - samples[n - 1].x, samples[0].z - samples[n - 1].z) : 0;
  for (let i = 0; i < count; i++) {
    const s = samples[i % n];
    const d = closed && i === n ? total : s.d;
    for (let j = 0; j < m; j++) {
      const k = i * m + j;
      pos[k * 3] = s.x + s.nx * cross[j][0];
      pos[k * 3 + 1] = cross[j][1];
      pos[k * 3 + 2] = s.z + s.nz * cross[j][0];
      uv[k * 2] = uScale ? u[j] / uScale : u[j] / ut;
      uv[k * 2 + 1] = d / vScale;
    }
  }
  const idx = [];
  for (let i = 0; i < count - 1; i++) for (let j = 0; j < m - 1; j++) {
    const a = i * m + j, b = a + m;
    idx.push(a, a + 1, b, a + 1, b + 1, b);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

let poleGeo = null, lampGeo = null, treeLeafGeo = null, treeTrunkGeo = null, boxGeo = null;
function sceneryGeos() {
  if (poleGeo) return;
  const p = new THREE.CylinderGeometry(0.12, 0.18, 10, 6); p.translate(0, 5, 0);
  const arm = new THREE.BoxGeometry(3.2, 0.14, 0.14); arm.translate(-1.5, 9.9, 0);
  poleGeo = mergeGeos([p, arm]);
  lampGeo = new THREE.BoxGeometry(0.9, 0.18, 0.4); lampGeo.translate(-2.9, 9.8, 0);
  const c1 = new THREE.ConeGeometry(2.4, 5.5, 7); c1.translate(0, 4.6, 0);
  const c2 = new THREE.ConeGeometry(1.8, 4.2, 7); c2.translate(0, 7.2, 0);
  const c3 = new THREE.ConeGeometry(1.1, 3, 7); c3.translate(0, 9.3, 0);
  treeLeafGeo = mergeGeos([c1, c2, c3]);
  treeTrunkGeo = new THREE.CylinderGeometry(0.25, 0.35, 2.4, 5); treeTrunkGeo.translate(0, 1.2, 0);
  boxGeo = new THREE.BoxGeometry(1, 1, 1); boxGeo.translate(0, 0.5, 0);
}

const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _p = new THREE.Vector3(), _c = new THREE.Color(), _up = new THREE.Vector3(0, 1, 0);

/** Road + walls + lamp posts for a list of samples */
function buildRoadGroup(samples, closed, q) {
  const Mt = materials();
  sceneryGeos();
  const g = new THREE.Group();
  const road = new THREE.Mesh(extrudeAlong(samples, [[-ROAD_HALF, 0.02], [ROAD_HALF, 0.02]], { closed, vScale: 12 }), Mt.road);
  road.receiveShadow = q >= 1;
  g.add(road);
  for (const side of [-1, 1]) {
    const a = side * WALL, b = side * (WALL + 0.55);
    const cross = side > 0 ? [[a, 0], [a, 0.95], [b, 1.0], [b, 0]] : [[b, 0], [b, 1.0], [a, 0.95], [a, 0]];
    const wall = new THREE.Mesh(extrudeAlong(samples, cross, { closed, vScale: 8 }), Mt.wall);
    wall.receiveShadow = q >= 1;
    g.add(wall);
  }
  // lamp posts every ~48m alternating sides
  const step = Math.max(1, Math.round(48 / Math.max(0.5, samples.length > 1 ? samples[1].d - samples[0].d : 2)));
  const items = [];
  for (let i = 0; i < samples.length; i += step) items.push(i);
  const poles = new THREE.InstancedMesh(poleGeo, Mt.pole, items.length);
  const lamps = new THREE.InstancedMesh(lampGeo, Mt.lamp, items.length);
  items.forEach((i, k) => {
    const s = samples[i];
    const side = (Math.round(s.d / 48) % 2 === 0) ? 1 : -1;
    const off = side * (WALL + 1.6);
    _p.set(s.x + s.nx * off, 0, s.z + s.nz * off);
    // local -X arm should point towards road center: direction = -side*n
    const dirX = -side * s.nx, dirZ = -side * s.nz;
    const ang = Math.atan2(dirZ, -dirX); // rotate local -X onto dir
    _q.setFromAxisAngle(_up, ang);
    _m.compose(_p, _q, _s.set(1, 1, 1));
    poles.setMatrixAt(k, _m);
    lamps.setMatrixAt(k, _m);
  });
  poles.castShadow = q >= 3;
  g.add(poles, lamps);
  return g;
}

function buildTrees(points, q, colorRand) {
  sceneryGeos();
  const Mt = materials();
  const leaf = new THREE.InstancedMesh(treeLeafGeo, Mt.leaf, points.length);
  const trunk = new THREE.InstancedMesh(treeTrunkGeo, Mt.trunk, points.length);
  points.forEach((p, i) => {
    _p.set(p[0], 0, p[1]);
    _q.setFromAxisAngle(_up, p[3] * 6.28);
    const sc = p[2];
    _m.compose(_p, _q, _s.set(sc, sc * (0.9 + p[3] * 0.4), sc));
    leaf.setMatrixAt(i, _m);
    trunk.setMatrixAt(i, _m);
    const r = colorRand();
    _c.setHSL(0.22 + r * 0.1, 0.45 + r * 0.2, 0.18 + r * 0.12);
    leaf.setColorAt(i, _c);
  });
  leaf.castShadow = q >= 2;
  const g = new THREE.Group();
  g.add(leaf, trunk);
  return g;
}

function buildBuildings(list, q) {
  sceneryGeos();
  const mesh = new THREE.InstancedMesh(boxGeo, materials().building, list.length);
  list.forEach((b, i) => {
    _p.set(b[0], 0, b[1]);
    _q.setFromAxisAngle(_up, b[5]);
    _m.compose(_p, _q, _s.set(b[2], b[3], b[4]));
    mesh.setMatrixAt(i, _m);
    _c.setHSL(0.08 + (i % 7) * 0.02, 0.15, 0.55 + (i % 3) * 0.12);
    mesh.setColorAt(i, _c);
  });
  mesh.castShadow = q >= 2;
  mesh.receiveShadow = q >= 2;
  return mesh;
}

function gantry(s, label = 'banner', q) {
  const Mt = materials();
  const g = new THREE.Group();
  for (const side of [-1, 1]) {
    const p = new THREE.Mesh(new THREE.BoxGeometry(0.8, 8, 0.8), Mt.gantry);
    p.position.set(side * (WALL + 1.2), 4, 0);
    g.add(p);
  }
  const beam = new THREE.Mesh(new THREE.BoxGeometry(2 * WALL + 3.2, 1.6, 0.5), Mt.gantry);
  beam.position.y = 7.6;
  g.add(beam);
  const ban = new THREE.Mesh(new THREE.PlaneGeometry(2 * WALL, 1.6), label === 'cp' ? Mt.cpBanner : Mt.banner);
  ban.position.set(0, 7.6, 0.27);
  const ban2 = ban.clone();
  ban2.position.z = -0.27;
  ban2.rotation.y = Math.PI;
  g.add(ban, ban2);
  g.position.set(s.x, 0, s.z);
  g.rotation.y = Math.atan2(s.tx, s.tz);
  if (q >= 2) g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  return g;
}

/* ---------------- Sky / environment ---------------- */
export function createSky() {
  const uniforms = {
    sunDir: { value: new THREE.Vector3(0.3, 0.15, 0.9).normalize() },
    time: { value: 0 },
    zenith: { value: new THREE.Color('#2c5d9e') },
    horizon: { value: new THREE.Color('#ffb070') },
    sunColor: { value: new THREE.Color('#ffc27a') },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms,
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    vertexShader: `varying vec3 vDir; void main(){ vDir = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `
      uniform vec3 sunDir; uniform float time; uniform vec3 zenith; uniform vec3 horizon; uniform vec3 sunColor;
      varying vec3 vDir;
      float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
      float noise(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*(3.0-2.0*f);
        return mix(mix(hash(i),hash(i+vec2(1,0)),u.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),u.x), u.y); }
      float fbm(vec2 p){ float v=0.0, a=0.5; for(int i=0;i<5;i++){ v+=a*noise(p); p*=2.03; a*=0.5; } return v; }
      void main(){
        vec3 d = normalize(vDir);
        float h = d.y;
        vec3 sd3 = normalize(sunDir);
        float sd = max(dot(d, sd3), 0.0);
        vec3 col = mix(horizon, zenith, pow(clamp(h, 0.0, 1.0), 0.42));
        col += sunColor * pow(sd, 5.0) * 0.55 * (1.0 - clamp(h * 1.6, 0.0, 1.0));
        col += sunColor * pow(sd, 48.0) * 0.9;
        col += vec3(1.0, 0.96, 0.88) * smoothstep(0.9990, 0.9996, sd) * 6.0;
        if (h < 0.0) col = mix(horizon * 0.9, vec3(0.42, 0.36, 0.38), clamp(-h * 5.0, 0.0, 1.0));
        if (h > 0.0) {
          vec2 uv = d.xz / (h + 0.12) * 0.55 + vec2(time * 0.004, time * 0.0015);
          float c = smoothstep(0.52, 0.86, fbm(uv * 1.5));
          vec3 cc = mix(vec3(0.98, 0.62, 0.5), vec3(1.0, 0.93, 0.82), pow(sd, 3.0));
          col = mix(col, cc * (0.7 + 0.6 * pow(sd, 6.0)), c * smoothstep(0.0, 0.18, h) * 0.8);
        }
        gl_FragColor = vec4(col, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(4000, 32, 16), mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = -10;
  return { mesh, uniforms };
}

export function createMountains(q) {
  const r = rng(1337);
  const geos = [];
  const count = q === 0 ? 26 : 46;
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 + r() * 0.1;
    const dist = 2300 + r() * 900;
    const h = 220 + r() * 520;
    const cg = new THREE.ConeGeometry(260 + r() * 420, h, 6 + Math.floor(r() * 3), 3);
    const p = cg.attributes.position;
    for (let k = 0; k < p.count; k++) {
      if (p.getY(k) < h / 2 - 1) {
        p.setX(k, p.getX(k) + (r() - 0.5) * 90);
        p.setZ(k, p.getZ(k) + (r() - 0.5) * 90);
        p.setY(k, p.getY(k) + (r() - 0.5) * 40);
      }
    }
    cg.translate(Math.cos(a) * dist, h / 2 - 20, Math.sin(a) * dist);
    geos.push(cg);
  }
  const geo = mergeGeos(geos);
  geo.computeVertexNormals();
  // vertex colors: haze purple at base, lighter near peaks
  const pos = geo.attributes.position;
  const cols = new Float32Array(pos.count * 3);
  const base = new THREE.Color('#6f6a8f'), top = new THREE.Color('#c9a3a0');
  for (let k = 0; k < pos.count; k++) {
    const t = Math.min(1, Math.max(0, pos.getY(k) / 600));
    _c.copy(base).lerp(top, t);
    cols[k * 3] = _c.r; cols[k * 3 + 1] = _c.g; cols[k * 3 + 2] = _c.b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(cols, 3));
  const mesh = new THREE.Mesh(geo, new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, fog: false }));
  mesh.frustumCulled = false;
  return mesh;
}

export function createGround() {
  const t = tex.grass.clone();
  t.needsUpdate = true;
  t.repeat.set(600, 600);
  const g = new THREE.Mesh(new THREE.PlaneGeometry(6000, 6000), new THREE.MeshStandardMaterial({ map: t, roughness: 1 }));
  g.rotation.x = -Math.PI / 2;
  g.receiveShadow = true;
  return g;
}

/* ---------------- Circuit track ---------------- */
export class CircuitTrack {
  constructor(data) {
    this.kind = 'circuit';
    this.data = data;
    this.checkpoints = data.points.map(([x, z]) => ({ x, z }));
    this.cpRadius = data.checkpointRadius;
    const curve = new THREE.CatmullRomCurve3(data.points.map(([x, z]) => new THREE.Vector3(x, 0, z)), true, 'centripetal');
    this.length = curve.getLength();
    const N = Math.round(this.length / 2);
    const pts = curve.getSpacedPoints(N);
    this.samples = [];
    for (let i = 0; i < N; i++) {
      const p = pts[i], nx = pts[(i + 1) % N], pv = pts[(i - 1 + N) % N];
      let tx = nx.x - pv.x, tz = nx.z - pv.z;
      const l = Math.hypot(tx, tz) || 1;
      tx /= l; tz /= l;
      this.samples.push({ x: p.x, z: p.z, tx, tz, nx: -tz, nz: tx, d: (i * this.length) / N });
    }
    this.N = N;
    this.step = this.length / N;
    // spatial hash for scenery rejection
    this.grid = new Map();
    this.samples.forEach((s, i) => {
      const k = `${Math.floor(s.x / 40)},${Math.floor(s.z / 40)}`;
      if (!this.grid.has(k)) this.grid.set(k, []);
      this.grid.get(k).push(i);
    });
    let minX = 1e9, maxX = -1e9, minZ = 1e9, maxZ = -1e9;
    for (const s of this.samples) { minX = Math.min(minX, s.x); maxX = Math.max(maxX, s.x); minZ = Math.min(minZ, s.z); maxZ = Math.max(maxZ, s.z); }
    this.bounds = { minX, maxX, minZ, maxZ };
  }
  distToRoad(x, z) {
    const cx = Math.floor(x / 40), cz = Math.floor(z / 40);
    let best = 1e9;
    for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) {
      const list = this.grid.get(`${cx + a},${cz + b}`);
      if (!list) continue;
      for (const i of list) {
        const s = this.samples[i];
        const d = (s.x - x) ** 2 + (s.z - z) ** 2;
        if (d < best) best = d;
      }
    }
    return Math.sqrt(best);
  }
  sample(i) { return this.samples[((i % this.N) + this.N) % this.N]; }
  /** Project world position onto the track. hint = previous sample index. */
  project(x, z, hint) {
    let bi = 0, bd = Infinity;
    if (hint == null || hint < 0) {
      for (let i = 0; i < this.N; i += 3) {
        const s = this.samples[i];
        const d = (s.x - x) ** 2 + (s.z - z) ** 2;
        if (d < bd) { bd = d; bi = i; }
      }
      hint = bi;
    }
    bd = Infinity;
    for (let k = -30; k <= 30; k++) {
      const i = (((hint + k) % this.N) + this.N) % this.N;
      const s = this.samples[i];
      const d = (s.x - x) ** 2 + (s.z - z) ** 2;
      if (d < bd) { bd = d; bi = i; }
    }
    const s = this.samples[bi];
    const dx = x - s.x, dz = z - s.z;
    const lat = dx * s.nx + dz * s.nz;
    let sd = s.d + dx * s.tx + dz * s.tz;
    if (sd < 0) sd += this.length;
    if (sd >= this.length) sd -= this.length;
    return { i: bi, s: sd, lat, tx: s.tx, tz: s.tz, nx: s.nx, nz: s.nz };
  }
  pointAt(sd, lat = 0) {
    const L = this.length;
    const s0 = ((sd % L) + L) % L;
    const f = s0 / this.step;
    const i = Math.floor(f);
    const a = this.sample(i), b = this.sample(i + 1);
    const t = f - i;
    const x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t;
    let tx = a.tx + (b.tx - a.tx) * t, tz = a.tz + (b.tz - a.tz) * t;
    const l = Math.hypot(tx, tz) || 1; tx /= l; tz /= l;
    return { x: x - tz * lat, z: z + tx * lat, tx, tz, i };
  }
  /** curvature-based safe speed around distance sd (for AI) */
  curvatureAhead(sd, ahead) {
    const a = this.pointAt(sd), b = this.pointAt(sd + ahead);
    const da = Math.atan2(b.tx, b.tz) - Math.atan2(a.tx, a.tz);
    const ang = Math.abs(Math.atan2(Math.sin(da), Math.cos(da)));
    return ang / ahead;
  }
  build(scene, q) {
    const group = new THREE.Group();
    group.add(buildRoadGroup(this.samples, true, q));
    group.add(gantry(this.samples[0], 'banner', q));
    // checkered start line
    const s0 = this.samples[0];
    const line = new THREE.Mesh(new THREE.PlaneGeometry(2 * ROAD_HALF, 2), materials().checker);
    line.rotation.x = -Math.PI / 2;
    line.rotation.z = Math.atan2(s0.tx, s0.tz);
    line.position.set(s0.x, 0.03, s0.z);
    group.add(line);
    // trees
    const r = rng(42);
    const treeCount = [450, 900, 1500, 2300][q];
    const pts = [];
    const { minX, maxX, minZ, maxZ } = this.bounds;
    let guard = 0;
    while (pts.length < treeCount && guard++ < treeCount * 12) {
      const x = minX - 450 + r() * (maxX - minX + 900);
      const z = minZ - 450 + r() * (maxZ - minZ + 900);
      const d = this.distToRoad(x, z);
      if (d < 19) continue;
      if (d > 120 && r() < 0.55) continue; // denser near the road
      pts.push([x, z, 0.8 + r() * 0.9, r()]);
    }
    group.add(buildTrees(pts, q, r));
    // buildings (town clusters)
    const bl = [];
    const centers = [[300, 300], [-260, 120], [760, -200], [250, -800], [900, 700]];
    for (const [cx, cz] of centers) {
      for (let k = 0; k < [10, 18, 26, 34][q]; k++) {
        const x = cx + (r() - 0.5) * 320, z = cz + (r() - 0.5) * 320;
        if (this.distToRoad(x, z) < 45) continue;
        bl.push([x, z, 14 + r() * 22, 12 + r() * (r() < 0.2 ? 90 : 35), 14 + r() * 22, Math.floor(r() * 4) * 0.4]);
      }
    }
    group.add(buildBuildings(bl, q));
    scene.add(group);
    this.group = group;
    return group;
  }
  dispose(scene) {
    if (!this.group) return;
    scene.remove(this.group);
    this.group.traverse((o) => { if (o.isMesh && o.geometry !== poleGeo && o.geometry !== lampGeo && o.geometry !== treeLeafGeo && o.geometry !== treeTrunkGeo && o.geometry !== boxGeo) o.geometry.dispose(); });
    this.group = null;
  }
}

/* ---------------- Endless highway ---------------- */
export class EndlessHighway {
  constructor() {
    this.kind = 'endless';
    this.chunkLen = 240;
    this.chunks = new Map();
    this.group = new THREE.Group();
    this.length = Infinity;
  }
  cx(z) { return 60 * Math.sin(z / 700) + 26 * Math.sin(z / 310 + 1.3); }
  dcx(z) { return (60 / 700) * Math.cos(z / 700) + (26 / 310) * Math.cos(z / 310 + 1.3); }
  sampleAt(z) {
    const x = this.cx(z), d = this.dcx(z), l = Math.hypot(d, 1);
    const tx = d / l, tz = 1 / l;
    return { x, z, tx, tz, nx: -tz, nz: tx, d: z };
  }
  project(x, z) {
    const s = this.sampleAt(z);
    const lat = (x - s.x) * s.nx;
    return { i: 0, s: z, lat, tx: s.tx, tz: s.tz, nx: s.nx, nz: s.nz };
  }
  pointAt(sd, lat = 0) {
    const s = this.sampleAt(sd);
    return { x: s.x + s.nx * lat, z: sd + s.nz * lat, tx: s.tx, tz: s.tz, i: 0 };
  }
  curvatureAhead() { return 0; }
  build(scene, q) {
    this.q = q;
    this.scene = scene;
    scene.add(this.group);
    this.update(0);
    return this.group;
  }
  update(z) {
    const ci = Math.floor(z / this.chunkLen);
    const want = new Set();
    for (let k = ci - 1; k <= ci + 6; k++) want.add(k);
    for (const [k, g] of this.chunks) {
      if (!want.has(k)) {
        this.group.remove(g);
        g.traverse((o) => { if (o.isMesh && o.userData.own) o.geometry.dispose(); });
        this.chunks.delete(k);
      }
    }
    for (const k of want) if (!this.chunks.has(k)) this.chunks.set(k, this.buildChunk(k));
  }
  buildChunk(k) {
    const q = this.q;
    const z0 = k * this.chunkLen;
    const samples = [];
    for (let z = z0; z <= z0 + this.chunkLen + 0.01; z += 4) samples.push(this.sampleAt(z));
    const g = buildRoadGroup(samples, false, q);
    g.traverse((o) => { if (o.isMesh && !o.isInstancedMesh) o.userData.own = true; });
    const r = rng(k * 7919 + 17);
    const pts = [];
    const n = [22, 45, 70, 95][q];
    for (let i = 0; i < n; i++) {
      const z = z0 + r() * this.chunkLen;
      const side = r() < 0.5 ? -1 : 1;
      const off = side * (18 + Math.pow(r(), 1.6) * 260);
      const s = this.sampleAt(z);
      pts.push([s.x + s.nx * off, z, 0.8 + r() * 0.9, r()]);
    }
    g.add(buildTrees(pts, q, r));
    if (r() < 0.55) {
      const bl = [];
      const side = r() < 0.5 ? -1 : 1;
      const cnt = [3, 5, 8, 10][q];
      for (let i = 0; i < cnt; i++) {
        const z = z0 + r() * this.chunkLen;
        const s = this.sampleAt(z);
        const off = side * (50 + r() * 200);
        bl.push([s.x + s.nx * off, z, 14 + r() * 20, 10 + r() * (r() < 0.25 ? 70 : 30), 14 + r() * 20, Math.atan2(s.tx, s.tz)]);
      }
      g.add(buildBuildings(bl, q));
    }
    this.group.add(g);
    return g;
  }
  makeCheckpointGate(z, q) {
    return gantry(this.sampleAt(z), 'cp', q);
  }
  dispose(scene) {
    for (const g of this.chunks.values()) {
      this.group.remove(g);
      g.traverse((o) => { if (o.isMesh && o.userData.own) o.geometry.dispose(); });
    }
    this.chunks.clear();
    scene.remove(this.group);
  }
}
