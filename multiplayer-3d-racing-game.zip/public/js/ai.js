import { buildCar, carStats, buildTraffic, TRAFFIC_LIST, TRAFFIC_COLORS, makeNameTag } from './cars.js';
import { LANES } from './track.js';

/* ---------------- AI racer (track follower with lane logic) ---------------- */
export class AIRacer {
  constructor(track, carId, color, q, skill, name, startS, lat) {
    this.track = track;
    this.model = buildCar(carId, color, q);
    this.root = this.model.root;
    this.stats = carStats(carId, { engine: 2, brakes: 2, handling: 2 });
    this.skill = skill;
    this.name = name;
    this.color = color;
    this.carId = carId;
    this.s = startS;
    this.lat = lat;
    this.targetLat = lat;
    this.speed = 0;
    this.len = 4.6; this.wid = 2;
    this.x = 0; this.z = 0; this.h = 0; this.vx = 0; this.vz = 0;
    this.finished = false; this.finishTime = null;
    this.laneTimer = 0;
    this.wheelRot = 0;
    this.tag = makeNameTag(name, color);
    this.root.add(this.tag);
    this.place();
  }
  place() {
    const p = this.track.pointAt(this.s, this.lat);
    this.x = p.x; this.z = p.z;
    const latVel = (this.targetLat - this.lat) * 0.06;
    this.h = Math.atan2(p.tx, p.tz) - latVel;
    this.vx = p.tx * this.speed; this.vz = p.tz * this.speed;
  }
  update(dt, others, playerProg, frozen, laps) {
    if (frozen) { this.place(); this.syncModel(dt); return; }
    const tr = this.track;
    const k = Math.max(tr.curvatureAhead(this.s + 5, 50), tr.curvatureAhead(this.s + 35, 70) * 0.9);
    const vmax = k > 1e-5 ? Math.sqrt(15.5 / k) : 999;
    let target = Math.min(this.stats.top * this.skill, vmax);
    if (this.finished) target = Math.min(target, 22);
    const gap = playerProg - this.s;
    if (!this.finished) {
      if (gap > 60) target *= 1 + Math.min(0.12, gap / 2000);
      else if (gap < -100) target *= 0.93;
    }
    // look ahead for blocking cars
    this.laneTimer -= dt;
    let blocked = null;
    for (const o of others) {
      if (o === this) continue;
      const ds = o.s - this.s;
      if (ds > 0 && ds < 22 && Math.abs(o.lat - this.lat) < 2.8) {
        if (!blocked || ds < blocked.ds) blocked = { ds, o };
      }
    }
    if (blocked) {
      if (this.laneTimer <= 0) {
        const free = LANES.filter((l) => !others.some((o) => o !== this && Math.abs(o.lat - l) < 2.6 && Math.abs(o.s - this.s) < 18));
        if (free.length) {
          free.sort((a, b) => Math.abs(a - this.lat) - Math.abs(b - this.lat));
          this.targetLat = free[0];
          this.laneTimer = 1.5;
        }
      }
      if (Math.abs(this.targetLat - blocked.o.lat) < 2.5) target = Math.min(target, (blocked.o.speed || 0) * 0.97 + blocked.ds * 0.3);
    } else if (this.laneTimer <= -6 && Math.random() < dt * 0.2) {
      this.targetLat = LANES[Math.floor(Math.random() * 4)];
      this.laneTimer = 2;
    }
    const acc = this.stats.accel * 0.85;
    const dv = target - this.speed;
    this.speed += Math.max(-20 * dt, Math.min(acc * dt * (1 - Math.min(0.6, this.speed / 120)), dv));
    this.speed = Math.max(0, this.speed);
    const ld = this.targetLat - this.lat;
    this.lat += Math.sign(ld) * Math.min(Math.abs(ld), 3.2 * dt);
    this.s += this.speed * dt;
    if (!this.finished && this.s >= laps * tr.length) this.finished = true;
    this.place();
    this.syncModel(dt);
  }
  syncModel(dt) {
    this.root.position.set(this.x, 0, this.z);
    this.root.rotation.y = this.h;
    this.wheelRot += (this.speed / this.model.wr) * dt;
    for (const w of this.model.wheels) {
      w.spin.rotation.x = this.wheelRot;
      if (w.front) w.pivot.rotation.y = (this.targetLat - this.lat) * 0.05;
    }
  }
}

/* ---------------- Highway traffic ---------------- */
export class TrafficSystem {
  constructor(scene, track, q, count) {
    this.scene = scene;
    this.track = track;
    this.cars = [];
    for (let i = 0; i < count; i++) {
      const type = TRAFFIC_LIST[i % TRAFFIC_LIST.length];
      const m = buildTraffic(type, TRAFFIC_COLORS[i % TRAFFIC_COLORS.length], q);
      scene.add(m.root);
      this.cars.push({ m, root: m.root, len: m.L, wid: m.W, type, s: 0, lat: 0, lane: 0, speed: 20, base: 20, x: 0, z: 0, h: 0, vx: 0, vz: 0, rel: 0, hitT: 0, nm: false });
    }
  }
  spawn(c, s) {
    c.lane = Math.floor(Math.random() * 4);
    c.lat = LANES[c.lane];
    c.s = s;
    c.base = c.type === 'truck' ? 18 + Math.random() * 5 : 21 + Math.random() * 11;
    c.speed = c.base;
    c.hitT = 0;
    c.nm = false;
    c.rel = NaN;
  }
  reset(ps) {
    this.cars.forEach((c, i) => this.spawn(c, ps + 60 + (i / this.cars.length) * 850 + Math.random() * 30));
    this.fixOverlaps();
  }
  fixOverlaps() {
    for (const a of this.cars) for (const b of this.cars) {
      if (a !== b && a.lane === b.lane && Math.abs(a.s - b.s) < 20) b.s += 30;
    }
  }
  update(dt, ps, playerSpeed) {
    for (const c of this.cars) {
      // follow car ahead in the same lane
      let desired = c.base;
      for (const o of this.cars) {
        if (o === c) continue;
        const ds = o.s - c.s;
        if (ds > 0 && ds < 30 && Math.abs(o.lat - c.lat) < 2.5) desired = Math.min(desired, o.speed - (30 - ds) * 0.15);
      }
      c.hitT = Math.max(0, c.hitT - dt);
      if (c.hitT > 0) desired = Math.min(desired, c.speed);
      c.speed += Math.max(-12 * dt, Math.min(4 * dt, desired - c.speed));
      c.speed = Math.max(0, c.speed);
      const tl = LANES[c.lane];
      c.lat += Math.sign(tl - c.lat) * Math.min(Math.abs(tl - c.lat), 1.6 * dt);
      c.s += c.speed * dt;
      if (c.s < ps - 140 || c.s > ps + 1000) {
        const ahead = playerSpeed > 12 || c.s < ps;
        let ns = ahead ? ps + 500 + Math.random() * 450 : ps - 120;
        this.spawn(c, ns);
        for (const o of this.cars) if (o !== c && o.lane === c.lane && Math.abs(o.s - c.s) < 25) c.s += 35;
        ns = c.s;
      }
      const p = this.track.pointAt(c.s, c.lat);
      c.x = p.x; c.z = p.z;
      c.h = Math.atan2(p.tx, p.tz);
      c.vx = p.tx * c.speed; c.vz = p.tz * c.speed;
      c.root.position.set(c.x, 0, c.z);
      c.root.rotation.y = c.h;
    }
  }
  dispose() {
    for (const c of this.cars) this.scene.remove(c.root);
    this.cars = [];
  }
}
