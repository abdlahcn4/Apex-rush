/* LAN multiplayer client (Socket.IO). Server is authoritative for race state. */
import { CAR_SPECS, PAINTS, buildCar, makeNameTag } from './cars.js';
import { save, settings, persistSettings, carColor, persist, isMobile } from './save.js';
import { esc } from './hud.js';

const $ = (id) => document.getElementById(id);
const SESSION = 'apexrush_mp_session';
const INTERP_DELAY = 100; // ms

export class Multiplayer {
  constructor(game) {
    this.game = game;
    this.socket = null;
    this.room = null;
    this.pid = null;
    this.key = null;
    this.code = null;
    this.remotes = new Map();
    this.standings = [];
    this.lan = null;
    this.inRace = false;
    this.sendAcc = 0;
    this.ping = 0;
    this.myCar = save.selected;
    this.myColor = carColor(save.selected);
    this.bindUI();
  }

  /* ---------------- connection ---------------- */
  async loadLanInfo() {
    try {
      const r = await fetch('/api/lan-info', { cache: 'no-store' });
      this.lan = await r.json();
    } catch {
      this.lan = { addresses: [], port: location.port || 80, urls: [], realtime: null, maxPlayersCap: 8 };
    }
    const urls = this.lan.urls?.length ? this.lan.urls : [location.origin];
    const isLocalHost = /^(localhost|127\.)/.test(location.hostname);
    const best = isLocalHost ? urls[0] : location.origin;
    this.joinUrl = best;
    const html = urls.map((u, i) => `<span>${esc(u)}${this.lan.addresses?.[i] ? ` <small>${esc(this.lan.addresses[i].iface)}</small>` : ''}</span>`).join('');
    const fallback = `<span>${esc(location.origin)}</span>`;
    $('lan-urls').innerHTML = (isLocalHost ? html : fallback) || fallback;
    $('lobby-urls').innerHTML = (isLocalHost ? html : fallback) || fallback;
    const qr = `/api/qr?text=${encodeURIComponent(best)}`;
    $('lan-qr').src = qr;
    $('lobby-qr').src = qr;
    const cap = this.lan.maxPlayersCap || 8;
    const opts = (lo, hi, sel) => Array.from({ length: hi - lo + 1 }, (_, i) => lo + i).map((n) => `<option value="${n}"${n === sel ? ' selected' : ''}>${n}</option>`).join('');
    $('host-max').innerHTML = opts(2, cap, Math.min(8, cap));
    $('host-laps').innerHTML = opts(1, 10, 3);
    $('lobby-laps').innerHTML = opts(1, 10, 3);
    $('lobby-max').innerHTML = opts(2, cap, Math.min(8, cap));
  }

  connect() {
    if (this.socket) return this.socket;
    if (typeof window.io !== 'function') {
      this.setError('Socket.IO client failed to load. Is the Node.js server running?');
      return null;
    }
    const rt = this.lan?.realtime;
    const url = rt && rt.mode === 'standalone' ? `${location.protocol}//${location.hostname}:${rt.port}` : undefined;
    const s = window.io(url, {
      transports: ['websocket', 'polling'],
      tryAllTransports: true,
      reconnection: true,
      reconnectionDelay: 400,
      reconnectionDelayMax: 2500,
      timeout: 8000,
    });
    this.socket = s;
    this.setConn('connecting…', '#ffd23f');
    s.on('connect', () => {
      this.setConn('● online', '#2ee59d');
      this.game.hud.net('');
      if (this.code && this.key) this.rejoin(true);
    });
    s.on('disconnect', () => {
      this.setConn('● reconnecting…', '#ff3b5c');
      if (this.code) this.game.hud.net('⚠ Connection lost — reconnecting…');
    });
    s.on('connect_error', () => this.setConn('● cannot reach server', '#ff3b5c'));
    s.on('room:update', (room) => this.onRoom(room));
    s.on('race:countdown', (d) => {
      this.standings = [];
      this.inRace = true;
      this.game.mpStartRace({ grid: d.grid, laps: d.laps, ms: d.ms, state: 'countdown' });
    });
    s.on('race:go', () => this.game.mpGo());
    s.on('snap', (d) => this.onSnap(d));
    s.on('race:state', (d) => { this.standings = d.standings; this.raceElapsed = d.elapsed; this.raceElapsedAt = performance.now(); });
    s.on('race:cp', (d) => this.game.mpCheckpoint(d));
    s.on('race:finish', (d) => this.game.mpFinish(d));
    s.on('race:results', (d) => { this.inRace = false; this.game.mpResults(d); });
    s.on('race:lobby', () => { this.inRace = false; this.game.mpLobby(); });
    s.on('race:notice', (d) => this.game.hud.toast(d.text, 3000));
    clearInterval(this.pingT);
    this.pingT = setInterval(() => {
      if (!s.connected) return;
      const t0 = performance.now();
      s.timeout(3000).emit('ping:check', t0, (err) => {
        if (err) return;
        this.ping = Math.round(performance.now() - t0);
        if (this.code) s.emit('ping:rtt', this.ping);
        if (this.inRace) this.game.hud.net(`ping ${this.ping} ms · ${this.remotes.size + 1} racers`);
      });
    }, 2000);
    return s;
  }

  setConn(text, color) {
    const c = $('mp-conn');
    c.textContent = text;
    c.style.color = color;
  }
  setError(t) { $('mp-error').textContent = t || ''; }

  me() { return { name: settings.name, car: this.myCar, color: this.myColor, device: isMobile ? 'mobile' : 'pc' }; }

  create() {
    const s = this.connect();
    if (!s) return;
    this.setError('');
    this.myCar = save.selected; this.myColor = carColor(save.selected);
    s.timeout(6000).emit('room:create', { ...this.me(), maxPlayers: +$('host-max').value, laps: +$('host-laps').value }, (err, res) => {
      if (err) return this.setError('Server did not respond. Check that server is running.');
      if (!res.ok) return this.setError(res.error);
      this.enter(res);
    });
  }
  join(code, key) {
    const s = this.connect();
    if (!s) return;
    code = (code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (code.length < 4) return this.setError('Enter the 4-letter room code shown on the host screen.');
    this.setError('');
    this.myCar = save.selected; this.myColor = carColor(save.selected);
    const doJoin = () => s.timeout(6000).emit('room:join', { ...this.me(), code, key }, (err, res) => {
      if (err) return this.setError('Server did not respond.');
      if (!res.ok) { if (key) this.clearSession(); return this.setError(res.error); }
      this.enter(res);
    });
    if (s.connected) doJoin(); else s.once('connect', doJoin);
  }
  rejoin(auto) {
    if (!this.socket || !this.code || !this.key) return;
    this.socket.timeout(6000).emit('room:join', { ...this.me(), code: this.code, key: this.key }, (err, res) => {
      if (err) return;
      if (!res.ok) {
        this.game.hud.net('');
        this.leaveLocal();
        this.game.toMenu('mp');
        this.setError(res.error);
        return;
      }
      if (auto) this.game.hud.toast('Reconnected', 1200);
      this.applyJoin(res);
    });
  }
  enter(res) {
    this.applyJoin(res);
    if (!res.race || (res.race.state !== 'racing' && res.race.state !== 'countdown')) this.game.showScreen('lobby');
  }
  applyJoin(res) {
    this.code = res.code; this.pid = res.pid; this.key = res.key;
    try { sessionStorage.setItem(SESSION, JSON.stringify({ code: this.code, key: this.key })); } catch { /* */ }
    this.onRoom(res.room);
    const r = res.race;
    if (r && (r.state === 'racing' || r.state === 'countdown')) {
      this.inRace = true;
      if (!this.game.mpActive()) this.game.mpStartRace({ grid: r.gridMap, laps: r.laps, ms: r.countdownMs, state: r.state, resume: r });
    }
  }
  leave() {
    this.socket?.emit('room:leave');
    this.leaveLocal();
  }
  leaveLocal() {
    this.clearSession();
    this.code = this.pid = this.key = null;
    this.room = null;
    this.inRace = false;
    this.clearRemotes();
  }
  clearSession() { try { sessionStorage.removeItem(SESSION); } catch { /* */ } }
  savedSession() { try { return JSON.parse(sessionStorage.getItem(SESSION) || 'null'); } catch { return null; } }
  isHost() { return this.room && this.room.hostPid === this.pid; }

  /* ---------------- lobby ---------------- */
  onRoom(room) {
    this.room = room;
    const me = room.players.find((p) => p.pid === this.pid);
    $('lobby-code').textContent = room.code;
    $('lobby-code2').textContent = room.code;
    $('lobby-count').textContent = `${room.players.filter((p) => p.connected).length}/${room.maxPlayers} players`;
    $('lobby-players').innerHTML = room.players.map((p) => `
      <li class="${p.connected ? '' : 'off'}">
        <span class="sw" style="background:${p.color}"></span>
        <span class="nm">${esc(p.name)}${p.pid === this.pid ? ' (you)' : ''}<small>${esc(CAR_SPECS[p.car]?.name || p.car)} · ${p.device === 'mobile' ? '📱 mobile' : '💻 PC'}${p.connected ? ` · ${p.ping} ms` : ' · disconnected'}</small></span>
        ${p.pid === room.hostPid ? '<span class="tag host">HOST</span>' : ''}
        <span class="tag ${p.ready ? 'rdy' : ''}">${p.ready ? 'READY' : 'NOT READY'}</span>
      </li>`).join('');
    const host = this.isHost();
    $('lobby-host-settings').style.display = host ? '' : 'none';
    $('btn-start').style.display = host ? '' : 'none';
    $('btn-ready').style.display = host ? 'none' : '';
    $('lobby-laps').value = room.laps;
    $('lobby-max').value = room.maxPlayers;
    if (me) {
      const rb = $('btn-ready');
      rb.textContent = me.ready ? '✔ READY' : 'READY UP';
      rb.classList.toggle('on', me.ready);
    }
    const waiting = room.players.filter((p) => !p.ready && p.pid !== room.hostPid && p.connected);
    $('lobby-msg').textContent = host
      ? room.players.length < 2 ? 'Waiting for players to join… (you can also start solo to test)' : waiting.length ? `Waiting for: ${waiting.map((p) => p.name).join(', ')}` : 'Everyone is ready — start the race!'
      : `Waiting for the host to start · ${room.laps} lap${room.laps > 1 ? 's' : ''}`;
    $('btn-start').disabled = waiting.length > 0;
    this.renderCarPicker();
    // update remote cars (name/color/car changes, disconnect state)
    for (const p of room.players) {
      const r = this.remotes.get(p.pid);
      if (r) {
        r.connected = p.connected;
        if (r.name !== p.name) { r.name = p.name; r.tag.userData.update(p.name); }
      }
    }
    for (const [pid] of this.remotes) if (!room.players.some((p) => p.pid === pid)) this.removeRemote(pid);
  }
  renderCarPicker() {
    const sel = $('lobby-car');
    const html = save.owned.map((id) => `<option value="${id}"${id === this.myCar ? ' selected' : ''}>${CAR_SPECS[id].name}</option>`).join('');
    if (sel.innerHTML !== html) sel.innerHTML = html;
    sel.value = this.myCar;
    $('lobby-colors').innerHTML = PAINTS.map((c) => `<button data-c="${c}" class="${c === this.myColor ? 'on' : ''}" style="background:${c}"></button>`).join('');
  }
  sendConfig(extra = {}) {
    this.socket?.emit('player:config', { name: settings.name, car: this.myCar, color: this.myColor, ...extra });
  }

  bindUI() {
    $('mp-name').addEventListener('change', (e) => { settings.name = e.target.value.trim().slice(0, 16) || settings.name; persistSettings(); });
    $('mp-tabs').addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return;
      for (const x of $('mp-tabs').children) x.classList.toggle('on', x === b);
      $('tab-host').hidden = b.dataset.tab !== 'host';
      $('tab-join').hidden = b.dataset.tab !== 'join';
    });
    $('btn-create').addEventListener('click', () => { settings.name = $('mp-name').value.trim().slice(0, 16) || settings.name; persistSettings(); this.create(); });
    $('btn-join').addEventListener('click', () => { settings.name = $('mp-name').value.trim().slice(0, 16) || settings.name; persistSettings(); this.join($('join-code').value); });
    $('join-code').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('btn-join').click(); });
    $('btn-rejoin').addEventListener('click', () => { const s = this.savedSession(); if (s) this.join(s.code, s.key); });
    $('btn-leave').addEventListener('click', () => { this.leave(); this.game.showScreen('mp'); });
    $('btn-ready').addEventListener('click', () => {
      const me = this.room?.players.find((p) => p.pid === this.pid);
      this.sendConfig({ ready: !(me && me.ready) });
    });
    $('btn-start').addEventListener('click', () => {
      this.socket?.timeout(5000).emit('race:start', {}, (err, res) => {
        if (err) return ($('lobby-msg').textContent = 'Server did not respond');
        if (!res.ok) $('lobby-msg').textContent = res.error;
      });
    });
    $('lobby-car').addEventListener('change', (e) => {
      this.myCar = e.target.value;
      this.myColor = carColor(this.myCar);
      save.selected = this.myCar; persist();
      this.sendConfig();
      this.game.setShowroomCar(this.myCar, this.myColor);
    });
    $('lobby-colors').addEventListener('click', (e) => {
      const c = e.target.dataset?.c; if (!c) return;
      this.myColor = c;
      save.colors[this.myCar] = c; persist();
      this.sendConfig();
      this.game.setShowroomCar(this.myCar, this.myColor);
    });
    $('lobby-laps').addEventListener('change', (e) => this.socket?.emit('room:settings', { laps: +e.target.value }));
    $('lobby-max').addEventListener('change', (e) => this.socket?.emit('room:settings', { maxPlayers: +e.target.value }));
  }
  onShowMp() {
    $('mp-name').value = settings.name;
    const s = this.savedSession();
    const rb = $('btn-rejoin');
    rb.hidden = !s;
    if (s) rb.textContent = `REJOIN ROOM ${s.code}`;
    if (isMobile) $('mp-tabs').children[1].click();
    this.connect();
  }

  /* ---------------- in-race networking ---------------- */
  spawnRemotes(scene, q) {
    this.clearRemotes();
    this.scene = scene;
    this.q = q;
    if (!this.room) return;
    for (const p of this.room.players) if (p.pid !== this.pid) this.addRemote(p);
  }
  addRemote(p) {
    const model = buildCar(p.car, p.color, this.q);
    const tag = makeNameTag(p.name, p.color);
    model.root.add(tag);
    this.scene.add(model.root);
    this.remotes.set(p.pid, { pid: p.pid, name: p.name, color: p.color, car: p.car, model, tag, buf: [], x: 0, z: 0, h: 0, vx: 0, vz: 0, speed: 0, steer: 0, brake: 0, len: 4.6, wid: 2, wheelRot: 0, connected: p.connected, visible: false });
    model.root.visible = false;
  }
  removeRemote(pid) {
    const r = this.remotes.get(pid);
    if (!r) return;
    this.scene?.remove(r.model.root);
    this.remotes.delete(pid);
  }
  clearRemotes() { for (const pid of [...this.remotes.keys()]) this.removeRemote(pid); }

  onSnap(d) {
    const now = performance.now();
    for (const e of d.p) {
      const [pid, x, z, h, speed, steer, throttle, brake, drift, conn] = e;
      if (pid === this.pid) continue;
      let r = this.remotes.get(pid);
      if (!r && this.scene && this.room) {
        const p = this.room.players.find((q) => q.pid === pid);
        if (p) { this.addRemote(p); r = this.remotes.get(pid); }
      }
      if (!r) continue;
      r.connected = !!conn;
      const last = r.buf[r.buf.length - 1];
      if (last && Math.hypot(last.x - x, last.z - z) > 60) r.buf.length = 0; // teleport/reset: snap
      r.buf.push({ t: now, x, z, h, speed, steer, throttle, brake, drift });
      if (r.buf.length > 30) r.buf.shift();
    }
  }
  updateRemotes(dt) {
    const rt = performance.now() - INTERP_DELAY;
    for (const r of this.remotes.values()) {
      const b = r.buf;
      if (!b.length) continue;
      let a = b[0], c = b[b.length - 1];
      let x, z, h, speed, steer, brake;
      if (rt <= a.t) ({ x, z, h, speed, steer, brake } = a);
      else if (rt >= c.t) {
        const ex = Math.min(0.25, (rt - c.t) / 1000);
        x = c.x + Math.sin(c.h) * c.speed * ex; z = c.z + Math.cos(c.h) * c.speed * ex;
        h = c.h; speed = c.speed; steer = c.steer; brake = c.brake;
      } else {
        for (let i = 0; i < b.length - 1; i++) if (b[i].t <= rt && b[i + 1].t >= rt) { a = b[i]; c = b[i + 1]; break; }
        const t = (rt - a.t) / Math.max(1, c.t - a.t);
        x = a.x + (c.x - a.x) * t; z = a.z + (c.z - a.z) * t;
        let dh = c.h - a.h; dh = Math.atan2(Math.sin(dh), Math.cos(dh));
        h = a.h + dh * t; speed = a.speed + (c.speed - a.speed) * t; steer = c.steer; brake = c.brake;
      }
      if (dt > 0) { r.vx = (x - r.x) / dt; r.vz = (z - r.z) / dt; }
      r.x = x; r.z = z; r.h = h; r.speed = speed; r.steer = steer; r.brake = brake;
      const m = r.model;
      m.root.visible = true;
      m.root.position.set(x, 0, z);
      m.root.rotation.y = h;
      r.wheelRot += (speed / m.wr) * dt;
      for (const w of m.wheels) { w.spin.rotation.x = r.wheelRot; if (w.front) w.pivot.rotation.y = -steer * 0.5; }
      m.tail.emissiveIntensity = brake > 0 ? 3.2 : 0.9;
      m.body.rotation.z += ((-steer * Math.min(1, Math.abs(speed) / 30) * 0.045) - m.body.rotation.z) * Math.min(1, dt * 6);
      r.tag.material.opacity = r.connected ? 1 : 0.35;
    }
  }
  sendState(v, dt) {
    if (!this.socket || !this.socket.connected || !this.code) return;
    this.sendAcc += dt;
    if (this.sendAcc < 1 / 30) return;
    this.sendAcc = 0;
    const r2 = (n) => Math.round(n * 100) / 100;
    this.socket.volatile.emit('s', [r2(v.x), r2(v.z), r2(v.h), r2(v.vF), r2(v.steer), v.throttle, v.brake, r2(v.drift)]);
  }
  backToLobby() { this.socket?.emit('race:lobby'); }
}
