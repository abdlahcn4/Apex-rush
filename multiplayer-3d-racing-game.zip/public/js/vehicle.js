import { buildCar, carStats } from './cars.js';
import { WALL } from './track.js';

const GEAR_TOPS = [0.17, 0.32, 0.47, 0.62, 0.79, 1.0];
const CAR_HALF_W = 1.0;

/** Player-driven vehicle with arcade drift physics. Forward = (sin h, cos h). */
export class Vehicle {
  constructor(id, color, upgrades, q) {
    this.id = id;
    this.model = buildCar(id, color, q);
    this.root = this.model.root;
    this.stats = carStats(id, upgrades);
    this.x = 0; this.z = 0; this.h = 0;
    this.vx = 0; this.vz = 0;
    this.steer = 0; this.throttle = 0; this.brake = 0; this.hand = false;
    this.speed = 0; this.vF = 0; this.vR = 0;
    this.rpm = 900; this.gear = 'N';
    this.drift = 0;
    this.pitch = 0; this.roll = 0; this.pv = 0; this.rv = 0;
    this.wheelRot = 0;
    this.hint = -1;
    this.proj = null;
    this.impact = 0;
    this.lastAccel = 0;
  }
  reset(x, z, h) {
    this.x = x; this.z = z; this.h = h;
    this.vx = this.vz = 0; this.steer = 0; this.drift = 0; this.hint = -1;
    this.sync(0);
  }
  get forward() { return [Math.sin(this.h), Math.cos(this.h)]; }

  update(dt, inp, track, frozen) {
    const st = this.stats;
    const fx = Math.sin(this.h), fz = Math.cos(this.h);
    const rx = -fz, rz = fx;
    let vF = this.vx * fx + this.vz * fz;
    const spd = Math.abs(vF);

    // steering smoothing (speed sensitive)
    const target = frozen ? 0 : inp.steer;
    const rate = inp.analog ? 10 : target === 0 ? 6 : 3.2;
    this.steer += Math.max(-rate * dt, Math.min(rate * dt, target - this.steer));
    this.throttle = frozen ? 0 : inp.throttle;
    this.brake = frozen ? 0 : inp.brake;
    this.hand = !frozen && inp.handbrake;

    // yaw
    const dir = vF >= 0 ? 1 : -1;
    const turn = st.handling * 2.15 / (1 + spd / 40) * Math.min(1, spd / 7);
    let yaw = -this.steer * turn * dir;
    if (this.hand && spd > 8) yaw *= 1.45;
    if (this.drift > 0.25) yaw *= 1.15;
    this.h += yaw * dt;

    // rebuild local velocity in new heading (this is what creates drift)
    const nfx = Math.sin(this.h), nfz = Math.cos(this.h);
    const nrx = -nfz, nrz = nfx;
    vF = this.vx * nfx + this.vz * nfz;
    let vR = this.vx * nrx + this.vz * nrz;

    // longitudinal
    let acc = 0;
    if (this.throttle > 0) {
      if (vF < -0.5) acc += st.brake * this.throttle;
      else {
        const f = Math.max(0, 1 - Math.pow(Math.max(0, vF) / st.top, 2.2));
        acc += st.accel * this.throttle * (0.35 + 0.65 * f) * (vF < st.top ? 1 : 0);
      }
    }
    if (this.brake > 0) {
      if (vF > 0.5) acc -= st.brake * this.brake;
      else if (vF > -14) acc -= 7 * this.brake;
    }
    if (this.hand) acc -= Math.sign(vF) * 7;
    // drag + rolling
    acc -= vF * Math.abs(vF) * 0.0008 + Math.sign(vF) * (this.throttle ? 0.3 : 1.6);
    const prevVF = vF;
    vF += acc * dt;
    if (!this.throttle && !this.brake && Math.abs(vF) < 0.3) vF = 0;
    if (Math.sign(prevVF) !== Math.sign(vF) && prevVF !== 0 && !this.brake && !this.throttle) vF = 0;

    // lateral grip
    let grip = 7.5 * st.handling;
    if (this.hand) grip = 1.1;
    else if (Math.abs(vR) > 5) grip *= 0.55;
    vR *= Math.exp(-grip * dt);
    this.drift = Math.min(1, Math.abs(vR) / Math.max(6, Math.abs(vF) * 0.5));

    this.vx = nfx * vF + nrx * vR;
    this.vz = nfz * vF + nrz * vR;
    this.x += this.vx * dt;
    this.z += this.vz * dt;
    this.vF = vF; this.vR = vR;
    this.speed = Math.hypot(this.vx, this.vz);
    this.lastAccel = acc;

    // walls
    this.impact = 0;
    if (track) {
      const p = track.project(this.x, this.z, this.hint);
      this.hint = p.i;
      const lim = WALL - CAR_HALF_W;
      if (Math.abs(p.lat) > lim) {
        const side = Math.sign(p.lat);
        const pen = Math.abs(p.lat) - lim;
        this.x -= p.nx * side * pen;
        this.z -= p.nz * side * pen;
        const vn = (this.vx * p.nx + this.vz * p.nz) * side;
        if (vn > 0) {
          this.vx -= p.nx * side * vn * 1.35;
          this.vz -= p.nz * side * vn * 1.35;
          this.impact = vn;
        }
        this.vx *= 0.992; this.vz *= 0.992;
        // align heading slightly with wall to avoid sticking
        const th = Math.atan2(p.tx, p.tz) + (this.vx * p.tx + this.vz * p.tz < 0 ? Math.PI : 0);
        let d = th - this.h; d = Math.atan2(Math.sin(d), Math.cos(d));
        this.h += d * Math.min(1, dt * 2.5);
      }
      this.proj = p;
    }

    // gears / rpm
    const kmh = Math.abs(vF) * 3.6;
    if (vF < -0.5) { this.gear = 'R'; this.rpm = 1500 + Math.abs(vF) * 220; }
    else if (kmh < 1 && !this.throttle) { this.gear = 'N'; this.rpm += (900 - this.rpm) * Math.min(1, dt * 5); }
    else {
      const frac = Math.max(0, vF) / st.top;
      let g = GEAR_TOPS.findIndex((t) => frac < t);
      if (g < 0) g = 5;
      const lo = g === 0 ? 0 : GEAR_TOPS[g - 1], hi = GEAR_TOPS[g];
      const r = (frac - lo) / (hi - lo);
      this.gear = String(g + 1);
      const target = 1300 + r * 6200 + (this.drift > 0.4 ? 900 : 0);
      this.rpm += (target - this.rpm) * Math.min(1, dt * 10);
    }
    if (!this.throttle && this.rpm > 1100) this.rpm -= dt * 800;
  }

  /** Update visual model: wheels, suspension. */
  sync(dt, ext) {
    const m = this.model;
    const steer = ext ? ext.steer : this.steer;
    const vF = ext ? ext.speed : this.vF;
    const brake = ext ? ext.brake : this.brake;
    this.root.position.set(this.x, 0, this.z);
    this.root.rotation.y = this.h;
    this.wheelRot += (vF / m.wr) * dt;
    for (const w of m.wheels) {
      w.spin.rotation.x = this.wheelRot;
      if (w.front) w.pivot.rotation.y = -steer * 0.5;
    }
    // suspension spring
    const accel = ext ? ext.accel || 0 : this.lastAccel;
    const lat = ext ? -steer * Math.min(1, Math.abs(vF) / 30) * 6 : -this.steer * Math.min(1, Math.abs(vF) / 30) * 6 - this.vR * 0.3;
    const pt = Math.max(-0.05, Math.min(0.05, -accel * 0.0028));
    const rt = Math.max(-0.06, Math.min(0.06, lat * 0.008));
    if (dt > 0) {
      this.pv += ((pt - this.pitch) * 90 - this.pv * 11) * dt;
      this.rv += ((rt - this.roll) * 90 - this.rv * 11) * dt;
      this.pitch += this.pv * dt;
      this.roll += this.rv * dt;
    }
    m.body.rotation.x = this.pitch;
    m.body.rotation.z = this.roll;
    m.body.position.y = Math.sin(performance.now() * 0.02 + this.x) * 0.004 * Math.min(1, Math.abs(vF) / 20);
    m.tail.emissiveIntensity = brake > 0 ? 3.2 : 0.9;
  }
}

/** Resolve collision between two circle-approximated cars. massB = Infinity → static push only for a. */
export function collideCars(a, b, massA = 1, massB = 1) {
  const r = 2.0;
  const dx = b.x - a.x, dz = b.z - a.z;
  // two-circle approximation along heading
  let best = null;
  const fa = [Math.sin(a.h), Math.cos(a.h)], fb = [Math.sin(b.h), Math.cos(b.h)];
  const la = a.len || 4.5, lb = b.len || 4.5;
  if (dx * dx + dz * dz > (la + lb) ** 2) return 0;
  for (const oa of [-la * 0.25, la * 0.25]) for (const ob of [-lb * 0.3, 0, lb * 0.3]) {
    const ax = a.x + fa[0] * oa, az = a.z + fa[1] * oa;
    const bx = b.x + fb[0] * ob, bz = b.z + fb[1] * ob;
    const ddx = bx - ax, ddz = bz - az;
    const d2 = ddx * ddx + ddz * ddz;
    const rr = r * 0.5 + (b.wid || 2) * 0.5;
    if (d2 < rr * rr && (!best || d2 < best.d2)) best = { d2, ddx, ddz, rr };
  }
  if (!best) return 0;
  const d = Math.sqrt(best.d2) || 0.01;
  const nx = best.ddx / d, nz = best.ddz / d;
  const pen = best.rr - d;
  const wa = massB === Infinity ? 1 : massB / (massA + massB);
  const wb = 1 - wa;
  a.x -= nx * pen * wa; a.z -= nz * pen * wa;
  if (wb > 0) { b.x += nx * pen * wb; b.z += nz * pen * wb; }
  const avx = a.vx || 0, avz = a.vz || 0, bvx = b.vx || 0, bvz = b.vz || 0;
  const rel = (bvx - avx) * nx + (bvz - avz) * nz;
  if (rel < 0) {
    const j = -(1 + 0.3) * rel;
    const ja = massB === Infinity ? j : (j * massB) / (massA + massB);
    a.vx = avx - nx * ja; a.vz = avz - nz * ja;
    if (massB !== Infinity && b.vx !== undefined) {
      const jb = (j * massA) / (massA + massB);
      b.vx = bvx + nx * jb; b.vz = bvz + nz * jb;
    }
    return -rel;
  }
  return 0;
}
