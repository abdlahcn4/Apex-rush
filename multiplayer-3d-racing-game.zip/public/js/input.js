/* Keyboard + touch input (buttons or steering wheel). */
export class Input {
  constructor() {
    this.keys = new Set();
    this.t = { left: false, right: false, gas: false, brake: false, hand: false, wheel: 0, wheelOn: false };
    this.handlers = { camera: null, pause: null, reset: null };
    this.enabled = false;
    addEventListener('keydown', (e) => {
      if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) return;
      const k = e.code;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(k) && this.enabled) e.preventDefault();
      if (!e.repeat) {
        if (k === 'KeyC') this.handlers.camera?.();
        if (k === 'Escape' || k === 'KeyP') this.handlers.pause?.();
        if (k === 'KeyR') this.handlers.reset?.();
      }
      this.keys.add(k);
    });
    addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('blur', () => { this.keys.clear(); Object.assign(this.t, { left: false, right: false, gas: false, brake: false, hand: false, wheel: 0, wheelOn: false }); });
    this.bindTouch();
  }
  bindTouch() {
    const bind = (id, prop) => {
      const el = document.getElementById(id);
      if (!el) return;
      const down = (e) => { e.preventDefault(); this.t[prop] = true; el.classList.add('down'); try { el.setPointerCapture(e.pointerId); } catch { /* */ } };
      const up = (e) => { e.preventDefault(); this.t[prop] = false; el.classList.remove('down'); };
      el.addEventListener('pointerdown', down);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
      el.addEventListener('lostpointercapture', up);
      el.addEventListener('contextmenu', (e) => e.preventDefault());
    };
    bind('t-left', 'left');
    bind('t-right', 'right');
    bind('t-gas', 'gas');
    bind('t-brake', 'brake');
    bind('t-hand', 'hand');
    const wrap = document.getElementById('t-wheel');
    const wheel = wrap?.querySelector('.wheel');
    if (!wheel) return;
    let pid = null;
    const setFrom = (e) => {
      const r = wheel.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const ang = Math.atan2(e.clientX - cx, cy - e.clientY); // 0 = up, + = right
      const v = Math.max(-1, Math.min(1, ang / (Math.PI / 2)));
      this.t.wheel = v;
      wheel.style.transform = `rotate(${v * 100}deg)`;
    };
    wheel.addEventListener('pointerdown', (e) => { e.preventDefault(); pid = e.pointerId; this.t.wheelOn = true; try { wheel.setPointerCapture(pid); } catch { /* */ } setFrom(e); });
    wheel.addEventListener('pointermove', (e) => { if (e.pointerId === pid) setFrom(e); });
    const end = (e) => { if (e.pointerId !== pid) return; pid = null; this.t.wheelOn = false; this.t.wheel = 0; wheel.style.transform = ''; };
    wheel.addEventListener('pointerup', end);
    wheel.addEventListener('pointercancel', end);
  }
  read() {
    const k = this.keys, t = this.t;
    const up = k.has('KeyW') || k.has('ArrowUp') || t.gas;
    const down = k.has('KeyS') || k.has('ArrowDown') || t.brake;
    const left = k.has('KeyA') || k.has('ArrowLeft') || t.left;
    const right = k.has('KeyD') || k.has('ArrowRight') || t.right;
    let steer = (right ? 1 : 0) - (left ? 1 : 0);
    let analog = false;
    if (t.wheelOn) { steer = t.wheel; analog = true; }
    return { throttle: up ? 1 : 0, brake: down ? 1 : 0, steer, analog, handbrake: k.has('Space') || t.hand };
  }
}
