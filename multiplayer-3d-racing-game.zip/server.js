/**
 * APEX RUSH — LAN host launcher
 *
 * Starts the Next.js app AND the Socket.IO multiplayer server on ONE port,
 * bound to all network interfaces so phones on the same Wi-Fi can join.
 *
 *   npm install
 *   npm run build
 *   node server.js            (production, recommended)
 *   node server.js --dev      (development mode with hot reload)
 *
 * Environment: PORT (default 3000), MAX_PLAYERS (default 8, max 16)
 *
 * Note: `npm run start` (next start) also works — the multiplayer server is
 * attached automatically by src/instrumentation.ts.
 */
const http = require("http");
const os = require("os");
const next = require("next");

const port = parseInt(process.env.PORT || "3000", 10);
const dev = process.argv.includes("--dev");
const app = next({ dev, hostname: "0.0.0.0", port });

let handle = null;
const pending = [];

const server = http.createServer((req, res) => {
  if (handle) return handle(req, res);
  pending.push([req, res]);
});

// Picked up by src/server/realtime.ts so Socket.IO shares this port
globalThis.__RACE_HTTP_SERVER = server;

server.listen(port, "0.0.0.0", async () => {
  await app.prepare();
  handle = app.getRequestHandler();
  if (dev) {
    const upgrade = app.getUpgradeHandler();
    server.on("upgrade", (req, socket, head) => {
      if (req.url && req.url.startsWith("/socket.io")) return;
      upgrade(req, socket, head);
    });
  }
  for (const [req, res] of pending.splice(0)) handle(req, res);

  const ips = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === "IPv4" && !a.internal) ips.push(`${a.address}  (${name})`);
  }
  console.log("\n==============================================");
  console.log("  APEX RUSH host is running" + (dev ? " [dev]" : ""));
  console.log(`  On this PC:  http://localhost:${port}`);
  for (const ip of ips) console.log(`  On phones:   http://${ip.split(" ")[0]}:${port}   ${ip.split(" ").slice(1).join(" ")}`);
  console.log("  Same Wi-Fi required. Allow Node.js through your firewall.");
  console.log("==============================================\n");
});
