@echo off
cd /d "%~dp0"
echo Starting Apex Rush (OpenGL) with full diagnostics...
echo.
apex-rush.exe --verbose
echo.
echo ------------------------------------------------------------
echo Exit code: %errorlevel%
echo If the game closed, copy the text above and send it back.
echo Log file: %APPDATA%\Godot\app_userdata\Apex Rush - Godot Slice\logs\godot.log
echo ------------------------------------------------------------
pause
