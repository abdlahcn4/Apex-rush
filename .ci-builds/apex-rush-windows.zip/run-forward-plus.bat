@echo off
cd /d "%~dp0"
echo Starting Apex Rush with the Vulkan (Forward+) renderer...
apex-rush.exe --rendering-method forward_plus --verbose
echo.
echo Exit code: %errorlevel%
pause
